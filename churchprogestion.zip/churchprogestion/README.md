# ChurchProGestion 🏛️

Application PWA professionnelle de gestion pour organisations religieuses.
**100% hors ligne** · React + TypeScript + Vite + IndexedDB

---

## ✨ Fonctionnalités

| Module | Description |
|--------|-------------|
| 📊 Tableau de bord | Vue globale, KPIs, alertes, comptes à rebours |
| 📅 Programmation annuelle | 54 semaines, thèmes, objectifs, activités |
| 🔥 Événements & Croisades | Création, suivi, 8 rubriques organisationnelles |
| 🚛 Logistique | Transport, hébergement, restauration, équipes |
| ⏱️ Planning journalier | Emplois du temps avec timeline visuelle |
| 👥 Ressources humaines | Membres, rôles, compétences, affectations |
| 💰 Finances | Recettes, dépenses, graphiques, export CSV |
| 💬 Témoignages | Texte, vidéo, approbation |
| 📦 Stock & Ventes | Inventaire, ventes, alertes de rupture |
| ⏳ Comptes à rebours | Temps réel, notifications, archivage auto |
| 🧠 Assistant IA local | Checklists, planification, conseils (hors ligne) |
| ⚙️ Paramètres | Thème, devise, sauvegarde, export |

---

## 🚀 Installation rapide

### Prérequis
- Node.js 18+ 
- npm ou yarn

### 1. Cloner le projet
```bash
git clone https://github.com/votre-username/churchprogestion.git
cd churchprogestion
```

### 2. Installer les dépendances
```bash
npm install
```

### 3. Lancer en développement
```bash
npm run dev
```

### 4. Build pour production
```bash
npm run build
```

---

## 🌐 Déploiement Vercel

### Option 1 : Via GitHub (recommandé)
1. Pushez le code sur GitHub
2. Connectez-vous sur [vercel.com](https://vercel.com)
3. Cliquez **"New Project"** → importez votre dépôt GitHub
4. Vercel détecte automatiquement Vite
5. Cliquez **"Deploy"**

### Option 2 : CLI Vercel
```bash
npm install -g vercel
vercel --prod
```

### Configuration Vercel (automatique)
Vercel détecte automatiquement :
- **Framework :** Vite
- **Build command :** `npm run build`
- **Output directory :** `dist`

---

## 📱 Installation Android (PWA)

### Depuis Chrome mobile :
1. Ouvrez l'URL de l'application dans Chrome
2. Attendez quelques secondes
3. Chrome affiche **"Ajouter à l'écran d'accueil"** → tapez **Installer**
4. L'application apparaît sur votre écran d'accueil comme une app native !

### Depuis l'application elle-même :
- Une bannière **"Installer"** apparaît dans la barre latérale
- Cliquez dessus pour déclencher l'installation

---

## 💾 Fonctionnement hors ligne

L'application utilise :
- **IndexedDB (Dexie.js)** pour toutes les données locales
- **Service Worker (Workbox)** pour le cache des assets
- **Stratégie Cache First** pour les ressources statiques

Une fois ouverte une première fois avec internet (pour charger les fonts Google), l'application fonctionne **entièrement sans connexion**.

---

## 🏗️ Architecture

```
src/
├── components/
│   ├── ui/          # Boutons, cartes, modals, inputs réutilisables
│   └── layout/      # AppLayout, sidebar, navigation
├── pages/           # Un fichier par module
├── db/              # Dexie.js, tables, seed data
├── store/           # Zustand (thème, settings globaux)
├── types/           # TypeScript interfaces
└── utils/           # Helpers, formateurs, exports
```

---

## 🔧 Stack technique

| Technologie | Usage |
|-------------|-------|
| React 18 | Interface utilisateur |
| TypeScript | Typage statique |
| Vite 5 | Build tool ultra-rapide |
| Tailwind CSS | Styles utilitaires |
| Dexie.js | Base de données IndexedDB |
| vite-plugin-pwa | Service Worker + Manifest |
| Workbox | Stratégies de cache offline |
| React Router v6 | Navigation SPA |
| Recharts | Graphiques financiers |
| Zustand | État global léger |
| Lucide React | Icônes |
| date-fns | Manipulation des dates |

---

## 📊 Données de démo

Au premier lancement, l'application génère automatiquement :
- 2 événements (croisade + conférence)
- 2 produits (bibles + cantiques)
- 3 transactions financières

---

## 🔐 Confidentialité

Toutes les données restent **exclusivement sur votre appareil**.
Aucune donnée n'est envoyée vers un serveur externe.
Aucun compte requis.

---

## 📤 Export des données

Depuis **Paramètres → Sauvegarde** :
- Export JSON complet de toutes les données
- Export CSV depuis Finances et Ventes

---

## 🤝 Contribution

Les contributions sont les bienvenues !

1. Fork le projet
2. Créez votre branche (`git checkout -b feature/amelioration`)
3. Committez (`git commit -m 'Ajout feature'`)
4. Push (`git push origin feature/amelioration`)
5. Ouvrez une Pull Request

---

## 📄 Licence

MIT © ChurchProGestion 2025
