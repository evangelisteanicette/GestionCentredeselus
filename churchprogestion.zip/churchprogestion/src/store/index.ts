import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Theme, AppSettings } from '@/types';

interface AppState {
  theme: Theme;
  sidebarOpen: boolean;
  settings: Partial<AppSettings>;
  isInstallable: boolean;
  deferredPrompt: BeforeInstallPromptEvent | null;

  setTheme: (t: Theme) => void;
  toggleTheme: () => void;
  setSidebarOpen: (v: boolean) => void;
  toggleSidebar: () => void;
  updateSettings: (s: Partial<AppSettings>) => void;
  setInstallable: (v: boolean, prompt?: BeforeInstallPromptEvent | null) => void;
}

// Extend Window type for BeforeInstallPromptEvent
interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      theme: 'dark',
      sidebarOpen: false,
      settings: {
        churchName: 'Mon Église',
        currency: 'XAF',
        language: 'fr',
      },
      isInstallable: false,
      deferredPrompt: null,

      setTheme: (theme) => {
        set({ theme });
        document.documentElement.classList.toggle('dark', theme === 'dark');
      },
      toggleTheme: () => {
        const next = get().theme === 'dark' ? 'light' : 'dark';
        get().setTheme(next);
      },
      setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
      toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
      updateSettings: (s) => set((state) => ({ settings: { ...state.settings, ...s } })),
      setInstallable: (isInstallable, deferredPrompt = null) =>
        set({ isInstallable, deferredPrompt }),
    }),
    {
      name: 'church-app-store',
      partialize: (state) => ({ theme: state.theme, settings: state.settings }),
    }
  )
);
