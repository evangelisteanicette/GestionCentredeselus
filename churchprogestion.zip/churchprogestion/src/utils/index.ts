import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format, formatDistanceToNow, differenceInDays } from 'date-fns';
import { fr } from 'date-fns/locale';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string, fmt = 'dd/MM/yyyy'): string {
  return format(new Date(date), fmt, { locale: fr });
}

export function formatDateTime(date: Date | string): string {
  return format(new Date(date), 'dd/MM/yyyy HH:mm', { locale: fr });
}

export function formatRelative(date: Date | string): string {
  return formatDistanceToNow(new Date(date), { addSuffix: true, locale: fr });
}

export function daysUntil(date: Date | string): number {
  return differenceInDays(new Date(date), new Date());
}

export function formatCurrency(amount: number, currency = 'XAF'): string {
  try {
    return new Intl.NumberFormat('fr-FR', { style: 'currency', currency, minimumFractionDigits: 0 }).format(amount);
  } catch {
    return `${amount.toLocaleString('fr-FR')} ${currency}`;
  }
}

export function formatNumber(n: number): string {
  return n.toLocaleString('fr-FR');
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

export function getInitials(name: string): string {
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
}

export function truncate(str: string, len = 50): string {
  return str.length > len ? str.slice(0, len) + '…' : str;
}

export function getWeekNumber(date: Date = new Date()): number {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}

export function getWeekDates(weekNumber: number, year: number): { start: Date; end: Date } {
  const simple = new Date(year, 0, 1 + (weekNumber - 1) * 7);
  const dow = simple.getDay();
  const start = new Date(simple);
  if (dow <= 4) start.setDate(simple.getDate() - simple.getDay() + 1);
  else start.setDate(simple.getDate() + 8 - simple.getDay());
  const end = new Date(start);
  end.setDate(start.getDate() + 6);
  return { start, end };
}

export const EVENT_TYPES: Record<string, string> = {
  croisade:    '🔥 Croisade',
  campagne:    '📣 Campagne',
  convention:  '🤝 Convention',
  seminaire:   '📚 Séminaire',
  conference:  '🎤 Conférence',
  veillée:     '🕯️ Veillée',
  retraite:    '🏕️ Retraite',
  reunion:     '👥 Réunion',
  autre:       '📅 Autre',
};

export const STATUS_LABELS: Record<string, string> = {
  draft:       'Brouillon',
  planned:     'Planifié',
  'in-progress': 'En cours',
  completed:   'Terminé',
  cancelled:   'Annulé',
};

export const STATUS_COLORS: Record<string, string> = {
  draft:       'bg-gray-500/20 text-gray-400',
  planned:     'bg-sky-500/20 text-sky-400',
  'in-progress': 'bg-amber-500/20 text-amber-400',
  completed:   'bg-emerald-500/20 text-emerald-400',
  cancelled:   'bg-red-500/20 text-red-400',
};

export const PERSON_ROLES: Record<string, string> = {
  pasteur:      'Pasteur',
  ancien:       'Ancien',
  diacre:       'Diacre',
  predicateur:  'Prédicateur',
  musicien:     'Musicien',
  choeur:       'Chœur',
  benevole:     'Bénévole',
  orateur:      'Orateur',
  artiste:      'Artiste',
  securite:     'Sécurité',
  medical:      'Médical',
  media:        'Médias',
  logistique:   'Logistique',
  administratif:'Administratif',
  autre:        'Autre',
};

export const SCHEDULE_TYPES: Record<string, { label: string; color: string }> = {
  priere:      { label: '🙏 Prière',      color: '#8b5cf6' },
  louange:     { label: '🎵 Louange',     color: '#f59e0b' },
  predication: { label: '📖 Prédication', color: '#6366f1' },
  enseignement:{ label: '📚 Enseignement',color: '#0ea5e9' },
  delivrance:  { label: '⚡ Délivrance',  color: '#ef4444' },
  culte:       { label: '⛪ Culte',       color: '#10b981' },
  pause:       { label: '☕ Pause',       color: '#6b7280' },
  autre:       { label: '📌 Autre',       color: '#ec4899' },
};

export function exportToJSON(data: unknown, filename: string): void {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename + '.json';
  a.click(); URL.revokeObjectURL(url);
}

export function exportToCSV(data: Record<string, unknown>[], filename: string): void {
  if (!data.length) return;
  const headers = Object.keys(data[0]);
  const rows = data.map(r => headers.map(h => JSON.stringify(r[h] ?? '')).join(','));
  const csv = [headers.join(','), ...rows].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename + '.csv';
  a.click(); URL.revokeObjectURL(url);
}
