import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AppLayout } from '@/components/layout/AppLayout';
import { DashboardPage }    from '@/pages/DashboardPage';
import { ProgrammingPage }  from '@/pages/ProgrammingPage';
import { EventsPage }       from '@/pages/EventsPage';
import { LogisticsPage }    from '@/pages/LogisticsPage';
import { PlanningPage }     from '@/pages/PlanningPage';
import { PeoplePage }       from '@/pages/PeoplePage';
import { FinancesPage }     from '@/pages/FinancesPage';
import { TestimoniesPage }  from '@/pages/TestimoniesPage';
import { StockPage }        from '@/pages/StockPage';
import { CountdownPage }    from '@/pages/CountdownPage';
import { AssistantPage }    from '@/pages/AssistantPage';
import { SettingsPage }     from '@/pages/SettingsPage';

export default function App() {
  return (
    <BrowserRouter>
      <AppLayout>
        <Routes>
          <Route path="/"              element={<DashboardPage />} />
          <Route path="/programmation" element={<ProgrammingPage />} />
          <Route path="/evenements"    element={<EventsPage />} />
          <Route path="/logistique"    element={<LogisticsPage />} />
          <Route path="/planning"      element={<PlanningPage />} />
          <Route path="/rh"            element={<PeoplePage />} />
          <Route path="/finances"      element={<FinancesPage />} />
          <Route path="/temoignages"   element={<TestimoniesPage />} />
          <Route path="/stock"         element={<StockPage />} />
          <Route path="/countdown"     element={<CountdownPage />} />
          <Route path="/assistant"     element={<AssistantPage />} />
          <Route path="/parametres"    element={<SettingsPage />} />
        </Routes>
      </AppLayout>
    </BrowserRouter>
  );
}
