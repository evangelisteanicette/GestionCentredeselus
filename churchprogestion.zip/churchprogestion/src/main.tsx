import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';
import { db, initSettings, seedDemoData } from '@/db';
import { useAppStore } from '@/store';

// Init DB and apply theme
async function bootstrap() {
  await initSettings();
  await seedDemoData();

  // Apply stored theme
  const state = useAppStore.getState();
  document.documentElement.classList.toggle('dark', state.theme === 'dark');

  // Listen for PWA install prompt
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    useAppStore.getState().setInstallable(true, e as any);
  });

  // Request notification permission
  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
  }
}

bootstrap().then(() => {
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
});
