// ─── GLOBAL ───────────────────────────────────────────────────────────────────

export type Theme = 'dark' | 'light';

export interface BaseEntity {
  id?: number;
  createdAt: Date;
  updatedAt: Date;
}

// ─── MODULE 1: PROGRAMMATION ANNUELLE ────────────────────────────────────────

export interface WeeklyProgram extends BaseEntity {
  weekNumber: number;        // 1-54
  year: number;
  theme: string;
  spiritualObjectives: string;
  numericalObjectives: string;
  responsible: string;
  activities: Activity[];
  indicators: string;
  report: string;
  status: 'planned' | 'in-progress' | 'completed' | 'cancelled';
  notes: string;
}

export interface Activity {
  id: string;
  name: string;
  description: string;
  time: string;
  duration: number; // minutes
  responsible: string;
}

// ─── MODULE 2: ÉVÉNEMENTS ─────────────────────────────────────────────────────

export type EventType =
  | 'croisade' | 'campagne' | 'convention' | 'seminaire'
  | 'conference' | 'veillée' | 'retraite' | 'reunion' | 'autre';

export type EventStatus = 'draft' | 'planned' | 'in-progress' | 'completed' | 'cancelled';

export interface ChurchEvent extends BaseEntity {
  name: string;
  type: EventType;
  location: string;
  startDate: Date;
  endDate: Date;
  startTime: string;
  endTime: string;
  responsible: string;
  budget: number;
  status: EventStatus;
  description: string;
  authorizations: EventSection;
  communication: EventSection;
  publicRelations: EventSection;
  security: EventSection;
  medical: EventSection;
  media: EventSection;
  equipment: EventSection;
  logistics: EventSection;
  color: string;
}

export interface EventSection {
  responsible: string;
  notes: string;
  tasks: SectionTask[];
  completed: boolean;
}

export interface SectionTask {
  id: string;
  name: string;
  done: boolean;
  assignedTo: string;
  dueDate?: string;
}

// ─── MODULE 3: LOGISTIQUE ─────────────────────────────────────────────────────

export interface LogisticsItem extends BaseEntity {
  eventId?: number;
  category: 'transport' | 'hebergement' | 'restauration' | 'benevole' | 'invite' | 'artiste' | 'orateur';
  name: string;
  description: string;
  quantity: number;
  unit: string;
  cost: number;
  supplier: string;
  status: 'pending' | 'confirmed' | 'delivered' | 'cancelled';
  notes: string;
  contactName: string;
  contactPhone: string;
  date?: Date;
}

// ─── MODULE 4: PLANNING JOURNALIER ───────────────────────────────────────────

export interface DailySchedule extends BaseEntity {
  eventId?: number;
  date: Date;
  title: string;
  items: ScheduleItem[];
}

export interface ScheduleItem {
  id: string;
  time: string;
  duration: number;
  type: 'priere' | 'louange' | 'predication' | 'enseignement' | 'delivrance' | 'culte' | 'pause' | 'autre';
  title: string;
  responsible: string;
  notes: string;
  color: string;
}

// ─── MODULE 5: RESSOURCES HUMAINES ───────────────────────────────────────────

export type PersonRole =
  | 'pasteur' | 'ancien' | 'diacre' | 'predicateur' | 'musicien'
  | 'choeur' | 'benevole' | 'orateur' | 'artiste' | 'securite'
  | 'medical' | 'media' | 'logistique' | 'administratif' | 'autre';

export interface Person extends BaseEntity {
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  role: PersonRole;
  function: string;
  availability: 'full' | 'partial' | 'unavailable';
  skills: string[];
  assignments: Assignment[];
  church: string;
  city: string;
  notes: string;
  photo?: string;
}

export interface Assignment {
  id: string;
  eventId?: number;
  eventName: string;
  role: string;
  startDate: string;
  endDate: string;
}

// ─── MODULE 6: FINANCES ───────────────────────────────────────────────────────

export type TransactionType = 'income' | 'expense';
export type IncomeCategory = 'don' | 'offrande' | 'sponsor' | 'vente' | 'autre';
export type ExpenseCategory = 'logistique' | 'communication' | 'hebergement' | 'restauration' | 'equipement' | 'honoraires' | 'autre';

export interface Transaction extends BaseEntity {
  eventId?: number;
  type: TransactionType;
  category: IncomeCategory | ExpenseCategory;
  amount: number;
  currency: string;
  description: string;
  date: Date;
  paymentMethod: 'cash' | 'transfer' | 'check' | 'mobile' | 'other';
  reference: string;
  validated: boolean;
  validatedBy: string;
  receiptUrl?: string;
  notes: string;
}

export interface Budget extends BaseEntity {
  eventId: number;
  totalBudget: number;
  currency: string;
  categories: BudgetCategory[];
  notes: string;
}

export interface BudgetCategory {
  id: string;
  name: string;
  allocated: number;
  spent: number;
}

// ─── MODULE 7: TÉMOIGNAGES ────────────────────────────────────────────────────

export type TestimonyType = 'guerison' | 'delivrance' | 'conversion' | 'benediction' | 'miracle' | 'autre';

export interface Testimony extends BaseEntity {
  eventId?: number;
  authorName: string;
  authorContact: string;
  type: TestimonyType;
  title: string;
  content: string;
  date: Date;
  photos: string[];
  videoUrl?: string;
  isPublic: boolean;
  approved: boolean;
  approvedBy: string;
}

// ─── MODULE 8: STOCK & VENTE ──────────────────────────────────────────────────

export type ProductCategory = 'livre' | 'brochure' | 'numerique' | 'audio' | 'video' | 'autre';

export interface Product extends BaseEntity {
  name: string;
  category: ProductCategory;
  author: string;
  description: string;
  price: number;
  cost: number;
  currency: string;
  stock: number;
  minStock: number;
  barcode: string;
  imageUrl?: string;
  isActive: boolean;
}

export interface Sale extends BaseEntity {
  eventId?: number;
  productId: number;
  productName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  currency: string;
  buyerName: string;
  date: Date;
  paymentMethod: string;
  notes: string;
}

export interface StockMovement extends BaseEntity {
  productId: number;
  type: 'in' | 'out' | 'adjustment';
  quantity: number;
  reason: string;
  date: Date;
  reference: string;
}

// ─── MODULE 10: COMPTE À REBOURS ─────────────────────────────────────────────

export interface Countdown extends BaseEntity {
  eventId?: number;
  name: string;
  targetDate: Date;
  color: string;
  isActive: boolean;
  notificationsEnabled: boolean;
  notificationsSent: number[];  // milestones in days already notified
  archived: boolean;
}

// ─── APP SETTINGS ─────────────────────────────────────────────────────────────

export interface AppSettings {
  id?: number;
  theme: Theme;
  language: string;
  currency: string;
  churchName: string;
  churchCity: string;
  currentYear: number;
  notifications: boolean;
  soundEnabled: boolean;
  fontSize: 'sm' | 'md' | 'lg';
  accentColor: string;
}
