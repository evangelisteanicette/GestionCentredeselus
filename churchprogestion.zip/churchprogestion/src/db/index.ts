import Dexie, { type Table } from 'dexie';
import type {
  WeeklyProgram, ChurchEvent, LogisticsItem, DailySchedule,
  Person, Transaction, Budget, Testimony, Product, Sale,
  StockMovement, Countdown, AppSettings
} from '@/types';

export class ChurchDB extends Dexie {
  weeklyPrograms!:  Table<WeeklyProgram,  number>;
  events!:          Table<ChurchEvent,    number>;
  logistics!:       Table<LogisticsItem,  number>;
  schedules!:       Table<DailySchedule,  number>;
  people!:          Table<Person,         number>;
  transactions!:    Table<Transaction,    number>;
  budgets!:         Table<Budget,         number>;
  testimonies!:     Table<Testimony,      number>;
  products!:        Table<Product,        number>;
  sales!:           Table<Sale,           number>;
  stockMovements!:  Table<StockMovement,  number>;
  countdowns!:      Table<Countdown,      number>;
  settings!:        Table<AppSettings,    number>;

  constructor() {
    super('ChurchProGestion');

    this.version(1).stores({
      weeklyPrograms: '++id, weekNumber, year, status, responsible',
      events:         '++id, type, status, startDate, endDate, responsible',
      logistics:      '++id, eventId, category, status',
      schedules:      '++id, eventId, date',
      people:         '++id, role, availability, lastName',
      transactions:   '++id, eventId, type, category, date',
      budgets:        '++id, eventId',
      testimonies:    '++id, eventId, type, approved, date',
      products:       '++id, category, isActive',
      sales:          '++id, eventId, productId, date',
      stockMovements: '++id, productId, date, type',
      countdowns:     '++id, eventId, isActive, archived',
      settings:       '++id',
    });
  }
}

export const db = new ChurchDB();

// ─── SEED DEFAULT SETTINGS ────────────────────────────────────────────────────
export async function initSettings(): Promise<void> {
  const count = await db.settings.count();
  if (count === 0) {
    await db.settings.add({
      theme: 'dark',
      language: 'fr',
      currency: 'XAF',
      churchName: 'Mon Église',
      churchCity: 'Ville',
      currentYear: new Date().getFullYear(),
      notifications: true,
      soundEnabled: true,
      fontSize: 'md',
      accentColor: '#6366f1',
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }
}

// ─── SEED DEMO DATA ───────────────────────────────────────────────────────────
export async function seedDemoData(): Promise<void> {
  const eventCount = await db.events.count();
  if (eventCount > 0) return;

  const now = new Date();
  const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 15);
  const nextWeek  = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 7);

  await db.events.bulkAdd([
    {
      name: 'Grande Croisade Évangélique 2025',
      type: 'croisade',
      location: 'Stade Municipal',
      startDate: nextMonth,
      endDate: new Date(nextMonth.getTime() + 7 * 86400000),
      startTime: '18:00',
      endTime: '22:00',
      responsible: 'Pasteur Jean Martin',
      budget: 5000000,
      status: 'planned',
      description: 'Grande croisade d\'évangélisation annuelle',
      authorizations:   { responsible: '', notes: '', tasks: [], completed: false },
      communication:    { responsible: '', notes: '', tasks: [], completed: false },
      publicRelations:  { responsible: '', notes: '', tasks: [], completed: false },
      security:         { responsible: '', notes: '', tasks: [], completed: false },
      medical:          { responsible: '', notes: '', tasks: [], completed: false },
      media:            { responsible: '', notes: '', tasks: [], completed: false },
      equipment:        { responsible: '', notes: '', tasks: [], completed: false },
      logistics:        { responsible: '', notes: '', tasks: [], completed: false },
      color: '#6366f1',
      createdAt: now,
      updatedAt: now,
    },
    {
      name: 'Conférence des Anciens',
      type: 'conference',
      location: 'Salle Polyvalente de l\'Église',
      startDate: nextWeek,
      endDate: new Date(nextWeek.getTime() + 2 * 86400000),
      startTime: '09:00',
      endTime: '17:00',
      responsible: 'Ancien Pierre Dubois',
      budget: 500000,
      status: 'planned',
      description: 'Conférence annuelle des anciens',
      authorizations:   { responsible: '', notes: '', tasks: [], completed: false },
      communication:    { responsible: '', notes: '', tasks: [], completed: false },
      publicRelations:  { responsible: '', notes: '', tasks: [], completed: false },
      security:         { responsible: '', notes: '', tasks: [], completed: false },
      medical:          { responsible: '', notes: '', tasks: [], completed: false },
      media:            { responsible: '', notes: '', tasks: [], completed: false },
      equipment:        { responsible: '', notes: '', tasks: [], completed: false },
      logistics:        { responsible: '', notes: '', tasks: [], completed: false },
      color: '#0ea5e9',
      createdAt: now,
      updatedAt: now,
    },
  ]);

  // Demo products
  await db.products.bulkAdd([
    {
      name: 'Bible Louis Segond',
      category: 'livre',
      author: 'Société Biblique',
      description: 'Bible complète, reliure rigide',
      price: 15000, cost: 8000, currency: 'XAF',
      stock: 50, minStock: 10,
      barcode: '9780000001',
      isActive: true,
      createdAt: now, updatedAt: now,
    },
    {
      name: 'Cantiques de Sion Vol.1',
      category: 'livre',
      author: 'Éditions Évangéliques',
      description: 'Recueil de chants',
      price: 5000, cost: 2500, currency: 'XAF',
      stock: 100, minStock: 20,
      barcode: '9780000002',
      isActive: true,
      createdAt: now, updatedAt: now,
    },
  ]);

  // Demo transactions
  await db.transactions.bulkAdd([
    {
      type: 'income', category: 'don',
      amount: 250000, currency: 'XAF',
      description: 'Don mensuel fidèles',
      date: new Date(now.getFullYear(), now.getMonth(), 1),
      paymentMethod: 'cash', reference: 'DON-001',
      validated: true, validatedBy: 'Trésorier',
      notes: '',
      createdAt: now, updatedAt: now,
    },
    {
      type: 'income', category: 'offrande',
      amount: 180000, currency: 'XAF',
      description: 'Offrande du culte dominical',
      date: new Date(now.getFullYear(), now.getMonth(), 7),
      paymentMethod: 'cash', reference: 'OFF-001',
      validated: true, validatedBy: 'Trésorier',
      notes: '',
      createdAt: now, updatedAt: now,
    },
    {
      type: 'expense', category: 'communication',
      amount: 50000, currency: 'XAF',
      description: 'Impression affiches croisade',
      date: new Date(now.getFullYear(), now.getMonth(), 10),
      paymentMethod: 'transfer', reference: 'DEP-001',
      validated: true, validatedBy: 'Trésorier',
      notes: '',
      createdAt: now, updatedAt: now,
    },
  ]);
}
