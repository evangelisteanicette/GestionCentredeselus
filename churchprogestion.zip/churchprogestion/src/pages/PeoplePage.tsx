import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Plus, Search, Users, Phone, Mail, Briefcase } from 'lucide-react';
import { db } from '@/db';
import { Card, Button, Input, Select, Modal, Badge, EmptyState, Textarea } from '@/components/ui';
import { getInitials, PERSON_ROLES, cn } from '@/utils';
import type { Person, PersonRole } from '@/types';

const AVAIL_COLORS = {
  full: 'bg-emerald-500/20 text-emerald-400',
  partial: 'bg-amber-500/20 text-amber-400',
  unavailable: 'bg-red-500/20 text-red-400',
};

const AVAIL_LABELS = { full: 'Disponible', partial: 'Partiel', unavailable: 'Indisponible' };

const ROLE_OPTS = Object.entries(PERSON_ROLES).map(([v, l]) => ({ value: v, label: l }));

export function PeoplePage() {
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Person | null>(null);
  const [form, setForm] = useState<Partial<Person>>({ role: 'benevole', availability: 'full', skills: [], assignments: [] });

  const people = useLiveQuery(() => db.people.orderBy('lastName').toArray(), []) || [];

  const filtered = people.filter(p => {
    const name = `${p.firstName} ${p.lastName}`.toLowerCase();
    const matchSearch = name.includes(search.toLowerCase()) || p.phone?.includes(search) || p.function?.toLowerCase().includes(search.toLowerCase());
    const matchRole = roleFilter === 'all' || p.role === roleFilter;
    return matchSearch && matchRole;
  });

  function openNew() { setEditing(null); setForm({ role: 'benevole', availability: 'full', skills: [], assignments: [] }); setModalOpen(true); }
  function openEdit(p: Person) { setEditing(p); setForm({ ...p }); setModalOpen(true); }

  async function save() {
    const now = new Date();
    if (editing?.id) {
      await db.people.update(editing.id, { ...form, updatedAt: now });
    } else {
      await db.people.add({ ...form, createdAt: now, updatedAt: now } as Person);
    }
    setModalOpen(false);
  }

  async function remove(id: number) {
    if (confirm('Supprimer cette personne ?')) await db.people.delete(id);
  }

  const byRole = Object.entries(PERSON_ROLES).map(([role, label]) => ({
    role, label,
    count: people.filter(p => p.role === role).length,
  })).filter(r => r.count > 0);

  const f = (k: string, v: unknown) => setForm(prev => ({ ...prev, [k]: v }));

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-white text-2xl">Ressources humaines</h1>
          <p className="text-gray-400 text-sm">{people.length} personne(s)</p>
        </div>
        <Button icon={<Plus size={16} />} onClick={openNew}>Ajouter</Button>
      </div>

      {/* Stats */}
      <div className="flex gap-2 flex-wrap">
        {byRole.map(r => (
          <button key={r.role} onClick={() => setRoleFilter(roleFilter === r.role ? 'all' : r.role)}
            className={cn('px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors',
              roleFilter === r.role ? 'bg-primary-600/30 border-primary-500/50 text-primary-300' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white')}>
            {r.label} <span className="opacity-60">({r.count})</span>
          </button>
        ))}
        {roleFilter !== 'all' && <button onClick={() => setRoleFilter('all')} className="text-xs text-gray-500 hover:text-white">✕ Tout</button>}
      </div>

      <Input placeholder="Rechercher par nom, téléphone…" value={search} onChange={e => setSearch(e.target.value)} icon={<Search size={14} />} />

      {filtered.length === 0 ? (
        <EmptyState icon={<Users />} title="Aucune personne trouvée" description="Ajoutez des membres à votre équipe" action={<Button size="sm" icon={<Plus size={14} />} onClick={openNew}>Ajouter</Button>} />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(p => (
            <PersonCard key={p.id} person={p} onEdit={() => openEdit(p)} onDelete={() => remove(p.id!)} />
          ))}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Modifier' : 'Nouvelle personne'} size="lg">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input label="Prénom *" value={form.firstName || ''} onChange={e => f('firstName', e.target.value)} />
            <Input label="Nom *" value={form.lastName || ''} onChange={e => f('lastName', e.target.value)} />
            <Input label="Téléphone" value={form.phone || ''} onChange={e => f('phone', e.target.value)} placeholder="+237 6XX XXX XXX" />
            <Input label="Email" type="email" value={form.email || ''} onChange={e => f('email', e.target.value)} />
            <Select label="Rôle" value={form.role || 'benevole'} onChange={e => f('role', e.target.value as PersonRole)} options={ROLE_OPTS} />
            <Select label="Disponibilité" value={form.availability || 'full'} onChange={e => f('availability', e.target.value as any)}
              options={[{ value: 'full', label: 'Disponible' }, { value: 'partial', label: 'Partiel' }, { value: 'unavailable', label: 'Indisponible' }]} />
            <Input label="Fonction" value={form.function || ''} onChange={e => f('function', e.target.value)} placeholder="Ex: Chef de sécurité" />
            <Input label="Église / Organisation" value={form.church || ''} onChange={e => f('church', e.target.value)} />
            <Input label="Ville" value={form.city || ''} onChange={e => f('city', e.target.value)} className="col-span-2" />
          </div>
          <Input label="Compétences (séparées par virgule)" value={(form.skills || []).join(', ')} onChange={e => f('skills', e.target.value.split(',').map(s => s.trim()).filter(Boolean))} placeholder="Ex: Chant, Guitare, Logistique" />
          <Textarea label="Notes" value={form.notes || ''} onChange={e => f('notes', e.target.value)} rows={3} />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Annuler</Button>
            <Button onClick={save} disabled={!form.firstName || !form.lastName}>Enregistrer</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function PersonCard({ person: p, onEdit, onDelete }: { person: Person; onEdit: () => void; onDelete: () => void }) {
  return (
    <Card className="p-4 hover:border-primary-500/30 transition-all">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-sky flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
          {getInitials(`${p.firstName} ${p.lastName}`)}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-1">
            <p className="font-display font-bold text-white text-sm truncate">{p.firstName} {p.lastName}</p>
            <div className="flex gap-1 flex-shrink-0">
              <button onClick={onEdit} className="p-1 rounded text-gray-400 hover:text-sky-400 transition-colors text-xs">✏️</button>
              <button onClick={onDelete} className="p-1 rounded text-gray-400 hover:text-red-400 transition-colors text-xs">🗑️</button>
            </div>
          </div>
          <div className="flex items-center gap-2 mt-1 flex-wrap">
            <Badge color="bg-primary-500/20 text-primary-300">{PERSON_ROLES[p.role]}</Badge>
            <Badge color={AVAIL_COLORS[p.availability]}>{AVAIL_LABELS[p.availability]}</Badge>
          </div>
          {p.function && <p className="text-xs text-gray-400 mt-1 flex items-center gap-1"><Briefcase size={10} />{p.function}</p>}
          {p.phone && <p className="text-xs text-gray-400 mt-0.5 flex items-center gap-1"><Phone size={10} />{p.phone}</p>}
          {p.skills?.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {p.skills.slice(0, 3).map(s => (
                <span key={s} className="text-xs bg-white/5 text-gray-400 px-2 py-0.5 rounded-full">{s}</span>
              ))}
              {p.skills.length > 3 && <span className="text-xs text-gray-500">+{p.skills.length - 3}</span>}
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
