import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Plus, TrendingUp, TrendingDown, DollarSign, Filter, Download } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { db } from '@/db';
import { Card, Button, Input, Select, Modal, StatCard, EmptyState, Textarea, Badge } from '@/components/ui';
import { formatDate, formatCurrency, exportToCSV } from '@/utils';
import type { Transaction } from '@/types';
import { useAppStore } from '@/store';

const INCOME_CATS = [
  { value: 'don', label: 'Don' },
  { value: 'offrande', label: 'Offrande' },
  { value: 'sponsor', label: 'Sponsor' },
  { value: 'vente', label: 'Vente' },
  { value: 'autre', label: 'Autre' },
];
const EXPENSE_CATS = [
  { value: 'logistique', label: 'Logistique' },
  { value: 'communication', label: 'Communication' },
  { value: 'hebergement', label: 'Hébergement' },
  { value: 'restauration', label: 'Restauration' },
  { value: 'equipement', label: 'Équipement' },
  { value: 'honoraires', label: 'Honoraires' },
  { value: 'autre', label: 'Autre' },
];
const PAYMENT_METHODS = [
  { value: 'cash', label: 'Espèces' },
  { value: 'transfer', label: 'Virement' },
  { value: 'check', label: 'Chèque' },
  { value: 'mobile', label: 'Mobile Money' },
  { value: 'other', label: 'Autre' },
];

const COLORS = ['#10b981','#6366f1','#0ea5e9','#f59e0b','#8b5cf6','#ef4444'];

export function FinancesPage() {
  const { settings } = useAppStore();
  const currency = settings.currency || 'XAF';
  const [modalOpen, setModalOpen] = useState(false);
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [form, setForm] = useState<Partial<Transaction>>({ type: 'income', category: 'don', currency, paymentMethod: 'cash', validated: false });

  const transactions = useLiveQuery(() => db.transactions.orderBy('date').reverse().toArray(), []) || [];

  const filtered = filterType === 'all' ? transactions : transactions.filter(t => t.type === filterType);

  const totalIncome  = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const totalExpense = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const balance      = totalIncome - totalExpense;

  // Monthly chart
  const now = new Date();
  const monthlyData = Array.from({ length: 6 }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
    const label = d.toLocaleString('fr-FR', { month: 'short' });
    const income  = transactions.filter(t => { const td = new Date(t.date); return t.type === 'income'  && td.getMonth() === d.getMonth() && td.getFullYear() === d.getFullYear(); }).reduce((s, t) => s + t.amount, 0);
    const expense = transactions.filter(t => { const td = new Date(t.date); return t.type === 'expense' && td.getMonth() === d.getMonth() && td.getFullYear() === d.getFullYear(); }).reduce((s, t) => s + t.amount, 0);
    return { label, income, expense };
  });

  // Category breakdown
  const catBreakdown = INCOME_CATS.map(c => ({
    name: c.label,
    value: transactions.filter(t => t.type === 'income' && t.category === c.value).reduce((s, t) => s + t.amount, 0),
  })).filter(c => c.value > 0);

  async function save() {
    const now = new Date();
    await db.transactions.add({ ...form, date: new Date(form.date || now), createdAt: now, updatedAt: now, notes: form.notes || '' } as Transaction);
    setModalOpen(false);
    setForm({ type: 'income', category: 'don', currency, paymentMethod: 'cash', validated: false });
  }

  function handleExport() {
    exportToCSV(filtered.map(t => ({
      Date: formatDate(t.date),
      Type: t.type === 'income' ? 'Recette' : 'Dépense',
      Catégorie: t.category,
      Montant: t.amount,
      Devise: t.currency,
      Description: t.description,
      'Mode de paiement': t.paymentMethod,
      Référence: t.reference,
    })), 'finances');
  }

  const f = (k: string, v: unknown) => setForm(prev => ({ ...prev, [k]: v }));

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-white text-2xl">Finances</h1>
          <p className="text-gray-400 text-sm">{transactions.length} transaction(s)</p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" icon={<Download size={14} />} onClick={handleExport}>Exporter</Button>
          <Button icon={<Plus size={16} />} onClick={() => setModalOpen(true)}>Nouvelle transaction</Button>
        </div>
      </div>

      {/* KPI */}
      <div className="grid grid-cols-3 gap-4">
        <StatCard label="Total recettes" value={formatCurrency(totalIncome, currency)} icon={<TrendingUp size={18} />} color="text-emerald-400" />
        <StatCard label="Total dépenses" value={formatCurrency(totalExpense, currency)} icon={<TrendingDown size={18} />} color="text-red-400" />
        <StatCard label="Solde" value={formatCurrency(balance, currency)} icon={<DollarSign size={18} />} color={balance >= 0 ? 'text-emerald-400' : 'text-red-400'} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Bar chart */}
        <Card className="p-5">
          <h2 className="font-display font-bold text-white text-base mb-4">Évolution mensuelle</h2>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={monthlyData}>
              <XAxis dataKey="label" tick={{ fill: '#9ca3af', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#9ca3af', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => v >= 1000 ? `${(v/1000).toFixed(0)}k` : v} />
              <Tooltip contentStyle={{ background: '#1a1a3e', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', color: '#fff', fontSize: '12px' }} />
              <Bar dataKey="income"  name="Recettes" fill="#10b981" radius={[4,4,0,0]} />
              <Bar dataKey="expense" name="Dépenses" fill="#ef4444" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Pie chart */}
        <Card className="p-5">
          <h2 className="font-display font-bold text-white text-base mb-4">Recettes par catégorie</h2>
          {catBreakdown.length === 0 ? (
            <EmptyState icon="📊" title="Aucune donnée" />
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={catBreakdown} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={11}>
                  {catBreakdown.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: '#1a1a3e', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', color: '#fff', fontSize: '12px' }} formatter={(v: number) => formatCurrency(v, currency)} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </Card>
      </div>

      {/* Transaction list */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-bold text-white text-base">Transactions</h2>
          <div className="flex gap-1">
            {(['all', 'income', 'expense'] as const).map(t => (
              <button key={t} onClick={() => setFilterType(t)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${filterType === t ? 'bg-primary-600 text-white' : 'bg-white/5 text-gray-400 hover:text-white'}`}>
                {t === 'all' ? 'Tout' : t === 'income' ? 'Recettes' : 'Dépenses'}
              </button>
            ))}
          </div>
        </div>
        {filtered.length === 0 ? (
          <EmptyState icon="💰" title="Aucune transaction" description="Enregistrez votre première transaction" />
        ) : (
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {filtered.map(t => (
              <div key={t.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/8 transition-colors">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${t.type === 'income' ? 'bg-emerald-500/20' : 'bg-red-500/20'}`}>
                  {t.type === 'income' ? <TrendingUp size={14} className="text-emerald-400" /> : <TrendingDown size={14} className="text-red-400" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-white text-sm truncate">{t.description || t.category}</p>
                  <p className="text-xs text-gray-400">{formatDate(t.date)} · {t.category} · {t.paymentMethod}</p>
                </div>
                <div className="text-right">
                  <p className={`font-bold font-display ${t.type === 'income' ? 'text-emerald-400' : 'text-red-400'}`}>
                    {t.type === 'income' ? '+' : '-'}{formatCurrency(t.amount, t.currency)}
                  </p>
                  {t.validated && <Badge color="bg-emerald-500/10 text-emerald-400">✓</Badge>}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* New transaction modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Nouvelle transaction" size="md">
        <div className="space-y-4">
          <div className="flex gap-2">
            <button onClick={() => f('type', 'income')} className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-colors ${form.type === 'income' ? 'bg-emerald-600 text-white' : 'bg-white/5 text-gray-400'}`}>Recette</button>
            <button onClick={() => f('type', 'expense')} className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-colors ${form.type === 'expense' ? 'bg-red-600 text-white' : 'bg-white/5 text-gray-400'}`}>Dépense</button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Montant *" type="number" value={form.amount || ''} onChange={e => f('amount', Number(e.target.value))} placeholder="0" />
            <Select label="Devise" value={form.currency || currency} onChange={e => f('currency', e.target.value)}
              options={[{ value: 'XAF', label: 'XAF (FCFA)' }, { value: 'EUR', label: 'EUR (€)' }, { value: 'USD', label: 'USD ($)' }]} />
            <Select label="Catégorie" value={form.category || ''} onChange={e => f('category', e.target.value)}
              options={form.type === 'income' ? INCOME_CATS : EXPENSE_CATS} />
            <Select label="Mode de paiement" value={form.paymentMethod || 'cash'} onChange={e => f('paymentMethod', e.target.value)} options={PAYMENT_METHODS} />
            <Input label="Date *" type="date" value={form.date instanceof Date ? form.date.toISOString().slice(0,10) : String(form.date || new Date().toISOString()).slice(0,10)} onChange={e => f('date', new Date(e.target.value))} />
            <Input label="Référence" value={form.reference || ''} onChange={e => f('reference', e.target.value)} placeholder="Ex: REC-001" />
          </div>
          <Input label="Description" value={form.description || ''} onChange={e => f('description', e.target.value)} placeholder="Description de la transaction…" />
          <div className="flex items-center gap-2">
            <input type="checkbox" id="validated" checked={!!form.validated} onChange={e => f('validated', e.target.checked)} className="w-4 h-4 accent-primary-600" />
            <label htmlFor="validated" className="text-sm text-gray-300">Transaction validée</label>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Annuler</Button>
            <Button onClick={save} disabled={!form.amount || !form.category}>Enregistrer</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
