import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Plus, Search, MessageSquare, Heart, Check, X } from 'lucide-react';
import { db } from '@/db';
import { Card, Button, Input, Select, Modal, Badge, EmptyState, Textarea } from '@/components/ui';
import { formatDate, cn } from '@/utils';
import type { Testimony, TestimonyType } from '@/types';

const TYPES: Record<TestimonyType, { label: string; emoji: string; color: string }> = {
  guerison:    { label: 'Guérison',    emoji: '💊', color: 'bg-emerald-500/20 text-emerald-400' },
  delivrance:  { label: 'Délivrance',  emoji: '⛓️', color: 'bg-violet-500/20 text-violet-400' },
  conversion:  { label: 'Conversion',  emoji: '✝️', color: 'bg-sky-500/20 text-sky-400' },
  benediction: { label: 'Bénédiction', emoji: '🙌', color: 'bg-amber-500/20 text-amber-400' },
  miracle:     { label: 'Miracle',     emoji: '✨', color: 'bg-pink-500/20 text-pink-400' },
  autre:       { label: 'Autre',       emoji: '📖', color: 'bg-gray-500/20 text-gray-400' },
};

export function TestimoniesPage() {
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [filterApproved, setFilterApproved] = useState<'all' | 'approved' | 'pending'>('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [viewing, setViewing] = useState<Testimony | null>(null);
  const [form, setForm] = useState<Partial<Testimony>>({
    type: 'guerison', isPublic: true, approved: false, photos: [], date: new Date(),
  });

  const testimonies = useLiveQuery(() => db.testimonies.orderBy('date').reverse().toArray(), []) || [];
  const events = useLiveQuery(() => db.events.toArray(), []) || [];

  const filtered = testimonies.filter(t => {
    const matchSearch = t.authorName.toLowerCase().includes(search.toLowerCase()) ||
      t.title.toLowerCase().includes(search.toLowerCase()) ||
      t.content.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === 'all' || t.type === typeFilter;
    const matchApproved = filterApproved === 'all' || (filterApproved === 'approved' ? t.approved : !t.approved);
    return matchSearch && matchType && matchApproved;
  });

  async function save() {
    const now = new Date();
    await db.testimonies.add({ ...form, createdAt: now, updatedAt: now, photos: form.photos || [] } as Testimony);
    setModalOpen(false);
    setForm({ type: 'guerison', isPublic: true, approved: false, photos: [], date: new Date() });
  }

  async function toggleApprove(t: Testimony) {
    await db.testimonies.update(t.id!, { approved: !t.approved, updatedAt: new Date() });
  }

  async function remove(id: number) {
    if (confirm('Supprimer ce témoignage ?')) await db.testimonies.delete(id);
  }

  const f = (k: string, v: unknown) => setForm(prev => ({ ...prev, [k]: v }));

  const typeCounts = Object.keys(TYPES).map(t => ({ type: t, count: testimonies.filter(x => x.type === t).length }));

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-white text-2xl">Témoignages</h1>
          <p className="text-gray-400 text-sm">{testimonies.length} témoignage(s) · {testimonies.filter(t => t.approved).length} approuvé(s)</p>
        </div>
        <Button icon={<Plus size={16} />} onClick={() => setModalOpen(true)}>Ajouter</Button>
      </div>

      {/* Type badges */}
      <div className="flex gap-2 flex-wrap">
        <button onClick={() => setTypeFilter('all')} className={cn('px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors', typeFilter === 'all' ? 'bg-primary-600/30 border-primary-500/50 text-primary-300' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white')}>
          Tous ({testimonies.length})
        </button>
        {typeCounts.filter(c => c.count > 0).map(({ type, count }) => {
          const info = TYPES[type as TestimonyType];
          return (
            <button key={type} onClick={() => setTypeFilter(typeFilter === type ? 'all' : type)}
              className={cn('px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors', typeFilter === type ? 'bg-primary-600/30 border-primary-500/50 text-primary-300' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white')}>
              {info.emoji} {info.label} ({count})
            </button>
          );
        })}
      </div>

      <div className="flex gap-3">
        <div className="flex-1">
          <Input placeholder="Rechercher…" value={search} onChange={e => setSearch(e.target.value)} icon={<Search size={14} />} />
        </div>
        <Select className="w-36" value={filterApproved} onChange={e => setFilterApproved(e.target.value as any)}
          options={[{ value: 'all', label: 'Tous' }, { value: 'approved', label: '✓ Approuvés' }, { value: 'pending', label: '⏳ En attente' }]} />
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={<MessageSquare />} title="Aucun témoignage" description="Enregistrez les témoignages des participants" action={<Button size="sm" icon={<Plus size={14} />} onClick={() => setModalOpen(true)}>Ajouter</Button>} />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filtered.map(t => (
            <TestimonyCard key={t.id} testimony={t} onView={() => setViewing(t)} onApprove={() => toggleApprove(t)} onDelete={() => remove(t.id!)} />
          ))}
        </div>
      )}

      {/* View modal */}
      {viewing && (
        <Modal open={!!viewing} onClose={() => setViewing(null)} title={viewing.title} size="lg">
          <div className="space-y-4">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge color={TYPES[viewing.type].color}>{TYPES[viewing.type].emoji} {TYPES[viewing.type].label}</Badge>
              <Badge color={viewing.approved ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}>
                {viewing.approved ? '✓ Approuvé' : '⏳ En attente'}
              </Badge>
              {viewing.isPublic && <Badge color="bg-sky-500/20 text-sky-400">Public</Badge>}
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <span>👤 {viewing.authorName}</span>
              {viewing.authorContact && <span>· {viewing.authorContact}</span>}
              <span>· {formatDate(viewing.date)}</span>
            </div>
            <p className="text-gray-200 text-sm leading-relaxed whitespace-pre-wrap bg-white/5 p-4 rounded-xl">{viewing.content}</p>
            {viewing.videoUrl && (
              <div className="p-3 rounded-xl bg-white/5">
                <p className="text-xs text-gray-400 mb-1">🎥 Vidéo</p>
                <a href={viewing.videoUrl} target="_blank" rel="noopener noreferrer" className="text-sky-400 text-sm hover:underline">{viewing.videoUrl}</a>
              </div>
            )}
            <div className="flex gap-3 justify-end">
              <Button variant={viewing.approved ? 'danger' : 'success'} size="sm" onClick={() => { toggleApprove(viewing); setViewing(null); }}>
                {viewing.approved ? 'Désapprouver' : '✓ Approuver'}
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Add modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Nouveau témoignage" size="lg">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input label="Nom de l'auteur *" value={form.authorName || ''} onChange={e => f('authorName', e.target.value)} />
            <Input label="Contact (tél/email)" value={form.authorContact || ''} onChange={e => f('authorContact', e.target.value)} />
            <Select label="Type" value={form.type || 'guerison'} onChange={e => f('type', e.target.value)}
              options={Object.entries(TYPES).map(([v, d]) => ({ value: v, label: `${d.emoji} ${d.label}` }))} />
            <Input label="Date" type="date" value={form.date instanceof Date ? form.date.toISOString().slice(0,10) : String(form.date || '').slice(0,10)} onChange={e => f('date', new Date(e.target.value))} />
            <Select label="Événement associé" value={String(form.eventId || '')} onChange={e => f('eventId', e.target.value ? Number(e.target.value) : undefined)}
              options={[{ value: '', label: '— Aucun —' }, ...events.map(e => ({ value: String(e.id), label: e.name }))]} className="col-span-2" />
          </div>
          <Input label="Titre du témoignage *" value={form.title || ''} onChange={e => f('title', e.target.value)} placeholder="Ex: Guérison miraculeuse" />
          <Textarea label="Contenu *" value={form.content || ''} onChange={e => f('content', e.target.value)} placeholder="Racontez le témoignage…" rows={5} />
          <Input label="URL vidéo (optionnel)" value={form.videoUrl || ''} onChange={e => f('videoUrl', e.target.value)} placeholder="https://…" />
          <div className="flex gap-4">
            <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
              <input type="checkbox" checked={!!form.isPublic} onChange={e => f('isPublic', e.target.checked)} className="w-4 h-4 accent-primary-600" />
              Témoignage public
            </label>
            <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
              <input type="checkbox" checked={!!form.approved} onChange={e => f('approved', e.target.checked)} className="w-4 h-4 accent-primary-600" />
              Approuvé
            </label>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Annuler</Button>
            <Button onClick={save} disabled={!form.authorName || !form.title || !form.content}>Enregistrer</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function TestimonyCard({ testimony: t, onView, onApprove, onDelete }: { testimony: Testimony; onView: () => void; onApprove: () => void; onDelete: () => void }) {
  const info = TYPES[t.type];
  return (
    <Card className="p-4 hover:border-primary-500/30 transition-all cursor-pointer" onClick={onView}>
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="flex items-center gap-2">
          <span className="text-xl">{info.emoji}</span>
          <div>
            <p className="font-display font-bold text-white text-sm">{t.title}</p>
            <p className="text-xs text-gray-400">{t.authorName} · {formatDate(t.date)}</p>
          </div>
        </div>
        <div className="flex gap-1 flex-shrink-0" onClick={e => e.stopPropagation()}>
          <button onClick={onApprove} className={cn('p-1.5 rounded-lg transition-colors', t.approved ? 'text-emerald-400 bg-emerald-500/10' : 'text-gray-400 hover:text-emerald-400')}>
            <Check size={13} />
          </button>
          <button onClick={onDelete} className="p-1.5 rounded-lg text-gray-400 hover:text-red-400 transition-colors"><X size={13} /></button>
        </div>
      </div>
      <p className="text-sm text-gray-300 line-clamp-3 leading-relaxed">{t.content}</p>
      <div className="flex gap-2 mt-3">
        <Badge color={info.color}>{info.label}</Badge>
        {t.approved && <Badge color="bg-emerald-500/20 text-emerald-400">✓</Badge>}
        {t.videoUrl && <Badge color="bg-sky-500/20 text-sky-400">🎥</Badge>}
      </div>
    </Card>
  );
}
