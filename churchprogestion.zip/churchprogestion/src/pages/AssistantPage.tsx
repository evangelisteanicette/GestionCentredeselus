import { useState, useRef, useEffect } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Brain, Send, Sparkles, ChevronDown } from 'lucide-react';
import { db } from '@/db';
import { Card, Button, Input } from '@/components/ui';
import { cn, formatDate } from '@/utils';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

// ─── LOCAL AI ENGINE (rule-based, no internet) ────────────────────────────────

function generateAIResponse(userMessage: string, context: {
  eventCount: number;
  upcomingEvents: string[];
  lowStockProducts: string[];
  balance: number;
  currency: string;
}): string {
  const msg = userMessage.toLowerCase().trim();

  // Checklist generation
  if (msg.includes('checklist') || msg.includes('liste') || msg.includes('vérification')) {
    if (msg.includes('croisade') || msg.includes('évangélisation') || msg.includes('evangelisation')) {
      return `✅ **Checklist Croisade Évangélique**

**📋 AUTORISATIONS (J-60)**
☐ Demande d'autorisation préfectorale
☐ Autorisation occupation espace public
☐ Notification forces de l'ordre
☐ Assurance événement

**📢 COMMUNICATION (J-30)**
☐ Impression affiches et flyers
☐ Annonces radio/TV locales
☐ Réseaux sociaux (création event)
☐ SMS de masse aux membres
☐ Coordination interéglises

**🛡️ SÉCURITÉ (J-15)**
☐ Briefing équipe sécurité
☐ Plan d'évacuation d'urgence
☐ Identification zones de secours
☐ Coordination forces de l'ordre

**⚕️ MÉDICAL (J-15)**
☐ Équipe médicale constituée
☐ Trousse de premiers secours
☐ Contacts urgences médicales
☐ Zone médicale balisée

**🔧 ÉQUIPEMENTS (J-7)**
☐ Sonorisation principale testée
☐ Générateurs électriques
☐ Éclairage scène et allées
☐ Écrans de projection
☐ Groupe électrogène secours

**🚛 LOGISTIQUE (J-3)**
☐ Transport orateurs confirmé
☐ Hébergement réservé
☐ Restauration planifiée
☐ Eau et sanitaires disponibles
☐ Parkings organisés

**📅 JOUR J**
☐ Arrivée équipe 3h avant
☐ Test sonorisation final
☐ Briefing général équipes
☐ Positions sécurité confirmées
☐ Point médical opérationnel`;
    }

    if (msg.includes('conférence') || msg.includes('conference') || msg.includes('séminaire') || msg.includes('seminaire')) {
      return `✅ **Checklist Conférence / Séminaire**

**📋 PRÉPARATION (J-30)**
☐ Thème et programme définis
☐ Orateurs confirmés
☐ Lieu réservé et confirmé
☐ Inscriptions ouvertes
☐ Documents de cours préparés

**📢 COMMUNICATION (J-14)**
☐ Invitations envoyées
☐ Programme distribué
☐ Confirmations reçues
☐ Badges préparés

**🔧 SALLE (J-1)**
☐ Disposition chaises/tables
☐ Sonorisation testée
☐ Vidéoprojecteur fonctionnel
☐ Climatisation/ventilation
☐ Connexion internet disponible
☐ Paperboard / tableau

**📅 JOUR J**
☐ Accueil participants dès J-1h
☐ Documents distribués
☐ Liste de présence signée
☐ Pause-café organisée`;
    }

    if (msg.includes('veillée') || msg.includes('prière') || msg.includes('priere')) {
      return `✅ **Checklist Veillée de Prière**

**📅 PRÉPARATION**
☐ Thème de prière défini
☐ Responsable louange désigné
☐ Prédicateur/animateur confirmé
☐ Équipe intercesseurs mobilisée

**🎵 LOUANGE**
☐ Liste de cantiques préparée
☐ Musiciens disponibles
☐ Paroles projetées (si écran)
☐ Ambiance lumières tamisées

**🙏 PROGRAMME**
☐ Louange d'ouverture (30 min)
☐ Enseignement / Parole (30 min)
☐ Intercession dirigée (60 min)
☐ Témoignages (15 min)
☐ Clôture et bénédiction`;
    }
  }

  // Planning help
  if (msg.includes('planning') || msg.includes('programme') || msg.includes('emploi du temps')) {
    return `📅 **Aide à la planification**

Je vous suggère une structure type pour votre programme :

**CULTE DOMINICAL (3h)**
• 09h00 – Louange et adoration (45 min)
• 09h45 – Annonces et offrande (15 min)
• 10h00 – Prédication (50 min)
• 10h50 – Appel et prière (20 min)
• 11h10 – Bénédiction finale (10 min)

**SOIRÉE D'ÉVANGÉLISATION (4h)**
• 17h30 – Accueil et installation
• 18h00 – Louange d'ouverture
• 18h45 – Témoignages
• 19h00 – Prédication principale
• 19h45 – Appel aux non-croyants
• 20h00 – Prière de délivrance
• 20h30 – Clôture

Voulez-vous que je personnalise ce programme ?`;
  }

  // Budget advice
  if (msg.includes('budget') || msg.includes('finances') || msg.includes('argent') || msg.includes('dépenses')) {
    const statusMsg = context.balance >= 0
      ? `✅ Solde positif : ${context.balance.toLocaleString()} ${context.currency}`
      : `⚠️ Déficit détecté : ${Math.abs(context.balance).toLocaleString()} ${context.currency}`;

    return `💰 **Conseils Budgétaires**

**Votre situation actuelle**
${statusMsg}

**Répartition recommandée pour un événement :**
• Logistique & transport : 25%
• Communication & médias : 20%
• Hébergement orateurs : 15%
• Restauration équipe : 15%
• Équipements & sonorisation : 15%
• Imprévus (réserve) : 10%

**Conseils pratiques :**
☑ Négociez toujours plusieurs devis
☑ Constituez une réserve de 10% minimum
☑ Payez en avance les prestations critiques
☑ Documentez chaque dépense avec reçu
☑ Faites valider les dépenses >50 000 XAF`;
  }

  // Evangelism tips
  if (msg.includes('évangélisation') || msg.includes('evangelisation') || msg.includes('âmes') || msg.includes('ames')) {
    return `🔥 **Stratégie d'Évangélisation**

**AVANT L'ÉVÉNEMENT**
• Mobiliser chaque membre pour inviter 3 personnes
• Distribuer des flyers dans les quartiers ciblés
• Utiliser les réseaux sociaux (WhatsApp, Facebook)
• Partenariats avec d'autres églises locales

**PENDANT L'ÉVÉNEMENT**
• Équipe d'accueil souriante et proactive
• Programme de qualité et bien rythmé
• Appel clair et simple à la conversion
• Équipe de suivi des nouveaux convertis

**APRÈS L'ÉVÉNEMENT**
• Enregistrement des coordonnées des convertis
• Visite à domicile dans les 48h
• Intégration dans un groupe de croissance
• Suivi téléphonique sur 30 jours

**Objectif suggéré :** Viser 10% du total des participants comme nouveaux convertis`;
  }

  // Security tips
  if (msg.includes('sécurité') || msg.includes('securite')) {
    return `🛡️ **Plan de Sécurité Événementiel**

**ORGANISATION**
• 1 agent pour 100 personnes minimum
• Chef de sécurité désigné et briefé
• Communication radio entre agents
• Plan de masse affiché aux entrées

**POSTES CLÉS**
• Contrôle d'accès aux entrées (2 agents)
• Surveillance périmètre (1 agent/angle)
• Protection scène (2 agents)
• Circulation interne (1 agent/zone)
• Zone médicale surveillée

**PROTOCOLES D'URGENCE**
• Signal d'évacuation connu de tous
• Sorties de secours dégagées
• Contact direct pompiers/police
• Point de rassemblement défini

**En cas d'incident :**
1. Sécuriser la zone
2. Alerter le responsable
3. Appeler les secours si nécessaire
4. Ne pas créer de panique`;
  }

  // Events summary
  if (msg.includes('événement') || msg.includes('evenement') || msg.includes('prochain')) {
    if (context.upcomingEvents.length === 0) {
      return `📅 **Vos événements**\n\nAucun événement à venir n'est planifié pour le moment.\n\n💡 **Conseil :** Planifiez vos événements au moins 3 mois à l'avance pour :\n• Obtenir les autorisations nécessaires\n• Mobiliser les équipes bénévoles\n• Sécuriser les sponsors\n• Préparer la communication`;
    }
    return `📅 **Vos prochains événements (${context.eventCount} au total)**\n\n${context.upcomingEvents.map((e, i) => `${i + 1}. ${e}`).join('\n')}\n\n💡 Besoin d'aide pour préparer l'un de ces événements ? Demandez-moi une checklist ou un plan de budget !`;
  }

  // Stock alert
  if (msg.includes('stock') || msg.includes('inventaire') || msg.includes('rupture')) {
    if (context.lowStockProducts.length === 0) {
      return `📦 **État du Stock**\n\n✅ Tous vos produits ont un stock satisfaisant !\n\n💡 **Bonnes pratiques de gestion de stock :**\n• Vérifiez l'inventaire avant chaque événement\n• Commandez 2 semaines avant rupture\n• Gardez un historique des ventes par événement`;
    }
    return `📦 **Alerte Stock**\n\n⚠️ Produits à réapprovisionner :\n${context.lowStockProducts.map(p => `• ${p}`).join('\n')}\n\n💡 **Recommandations :**\n• Commandez immédiatement ces articles\n• Prévoyez 20% de stock supplémentaire avant les grands événements`;
  }

  // Help
  if (msg.includes('aide') || msg.includes('help') || msg.includes('quoi') || msg.includes('comment')) {
    return `🧠 **ChurchPro Assistant - Ce que je peux faire**

Je suis votre assistant intelligent local (100% hors ligne) !

**📋 Checklists (tapez "checklist [type]")**
• Checklist croisade
• Checklist conférence/séminaire
• Checklist veillée de prière

**📅 Planification**
• "Aide-moi à planifier mon programme"
• "Donne-moi un emploi du temps type"

**💰 Finances**
• "Conseils budget événement"
• "Comment gérer mes dépenses"

**🔥 Évangélisation**
• "Stratégie d'évangélisation"
• "Comment mobiliser l'équipe"

**🛡️ Sécurité**
• "Plan de sécurité événement"

**📊 Résumés**
• "Montre mes événements"
• "État du stock"

Que voulez-vous faire ?`;
  }

  // Greeting
  if (msg.includes('bonjour') || msg.includes('salut') || msg.includes('bonsoir') || msg.length < 10) {
    const hour = new Date().getHours();
    const greeting = hour < 12 ? 'Bonjour' : hour < 18 ? 'Bon après-midi' : 'Bonsoir';
    return `${greeting} ! 👋\n\nJe suis **ChurchPro Assistant**, votre aide intelligent local pour la gestion d'événements religieux.\n\nVous avez actuellement **${context.eventCount} événement(s)** enregistré(s).\n\nTapez **"aide"** pour voir tout ce que je peux faire pour vous !`;
  }

  // Default
  return `Je n'ai pas bien compris votre demande. Voici ce que je peux vous aider à faire :

• **Checklists** : tapez "checklist croisade", "checklist conférence"
• **Planification** : tapez "aide planning"
• **Budget** : tapez "conseils budget"
• **Évangélisation** : tapez "stratégie évangélisation"
• **Sécurité** : tapez "plan sécurité"
• **Stock** : tapez "état stock"
• **Événements** : tapez "prochains événements"

Tapez **"aide"** pour la liste complète.`;
}

const QUICK_PROMPTS = [
  { label: '📋 Checklist croisade', prompt: 'Génère une checklist pour une croisade' },
  { label: '📅 Programme type', prompt: 'Aide-moi à planifier mon programme' },
  { label: '💰 Conseils budget', prompt: 'Donne-moi des conseils budget' },
  { label: '🛡️ Plan sécurité', prompt: 'Plan de sécurité événement' },
  { label: '🔥 Stratégie évangélisation', prompt: 'Stratégie d\'évangélisation' },
];

export function AssistantPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '0',
      role: 'assistant',
      content: `Bonjour ! 👋 Je suis **ChurchPro Assistant**, votre aide intelligent local.\n\nJe fonctionne **100% hors ligne** et je peux vous aider avec :\n• Génération de checklists\n• Aide à la planification\n• Conseils budgétaires\n• Stratégies d'évangélisation\n\nTapez **"aide"** pour voir toutes mes fonctionnalités !`,
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const events = useLiveQuery(() => db.events.where('status').notEqual('cancelled').toArray(), []) || [];
  const products = useLiveQuery(() => db.products.toArray(), []) || [];
  const transactions = useLiveQuery(() => db.transactions.toArray(), []) || [];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  async function sendMessage(text?: string) {
    const msgText = text || input.trim();
    if (!msgText) return;
    setInput('');

    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: msgText, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setIsTyping(true);

    // Context
    const now = new Date();
    const upcoming = events.filter(e => new Date(e.startDate) > now).slice(0, 5).map(e => `${e.name} (${formatDate(e.startDate)})`);
    const lowStock = products.filter(p => p.stock <= p.minStock && p.isActive).map(p => `${p.name} (${p.stock} restant)`);
    const balance = transactions.reduce((s, t) => t.type === 'income' ? s + t.amount : s - t.amount, 0);

    // Simulate thinking delay
    await new Promise(r => setTimeout(r, 600 + Math.random() * 800));

    const response = generateAIResponse(msgText, {
      eventCount: events.length,
      upcomingEvents: upcoming,
      lowStockProducts: lowStock,
      balance,
      currency: 'XAF',
    });

    setIsTyping(false);
    setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'assistant', content: response, timestamp: new Date() }]);
  }

  function formatContent(text: string) {
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>')
      .replace(/^(#{1,3})\s(.+)$/gm, '<span class="font-display font-bold text-white">$2</span>')
      .replace(/^(☐|☑|✅|⚠️|💡|•)/gm, (m) => `<span>${m}</span>`)
      .replace(/\n/g, '<br/>');
  }

  return (
    <div className="flex flex-col h-[calc(100vh-9rem)]">
      <div className="mb-4">
        <h1 className="font-display font-bold text-white text-2xl">Assistant IA Local</h1>
        <p className="text-gray-400 text-sm flex items-center gap-1">
          <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
          100% hors ligne · Basé sur des règles intelligentes
        </p>
      </div>

      {/* Quick prompts */}
      <div className="flex gap-2 flex-wrap mb-4">
        {QUICK_PROMPTS.map(qp => (
          <button key={qp.label} onClick={() => sendMessage(qp.prompt)}
            className="px-3 py-1.5 rounded-xl bg-primary-600/20 border border-primary-500/30 text-primary-300 text-xs font-semibold hover:bg-primary-600/40 transition-colors">
            {qp.label}
          </button>
        ))}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-1">
        {messages.map(msg => (
          <div key={msg.id} className={cn('flex gap-3', msg.role === 'user' ? 'justify-end' : 'justify-start')}>
            {msg.role === 'assistant' && (
              <div className="w-8 h-8 rounded-xl bg-gradient-sky flex items-center justify-center flex-shrink-0 mt-1">
                <Brain size={14} className="text-white" />
              </div>
            )}
            <div className={cn(
              'max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed font-body',
              msg.role === 'user'
                ? 'bg-primary-600 text-white rounded-tr-sm'
                : 'bg-surface-card border border-white/10 text-gray-200 rounded-tl-sm'
            )}>
              {msg.role === 'assistant' ? (
                <div dangerouslySetInnerHTML={{ __html: formatContent(msg.content) }} />
              ) : msg.content}
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex gap-3 justify-start">
            <div className="w-8 h-8 rounded-xl bg-gradient-sky flex items-center justify-center flex-shrink-0">
              <Brain size={14} className="text-white" />
            </div>
            <div className="bg-surface-card border border-white/10 rounded-2xl rounded-tl-sm px-4 py-3">
              <div className="flex gap-1">
                {[0, 1, 2].map(i => (
                  <div key={i} className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="flex gap-3">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
          placeholder="Posez votre question… (ex: checklist croisade)"
          className="flex-1 bg-surface-card border border-white/15 rounded-xl text-white placeholder-gray-500 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500/50 transition-all"
        />
        <Button onClick={() => sendMessage()} disabled={!input.trim() || isTyping} icon={<Send size={16} />} className="flex-shrink-0">
          Envoyer
        </Button>
      </div>
    </div>
  );
}
