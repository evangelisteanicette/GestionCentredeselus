import { useState, useEffect } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Settings, Download, Upload, Trash2, Info, Moon, Sun, Bell, Globe, Database } from 'lucide-react';
import { db } from '@/db';
import { Card, Button, Input, Select } from '@/components/ui';
import { useAppStore } from '@/store';
import { exportToJSON } from '@/utils';

export function SettingsPage() {
  const { theme, toggleTheme, settings, updateSettings } = useAppStore();
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({
    churchName: settings.churchName || '',
    churchCity: settings.churchCity || '',
    currency: settings.currency || 'XAF',
    language: settings.language || 'fr',
    fontSize: settings.fontSize || 'md',
    notifications: settings.notifications !== false,
  });

  function f(k: string, v: unknown) { setForm(prev => ({ ...prev, [k]: v })); }

  async function save() {
    updateSettings(form);
    const existing = await db.settings.toCollection().first();
    if (existing?.id) {
      await db.settings.update(existing.id, { ...form, updatedAt: new Date() });
    }
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  async function exportAllData() {
    const [events, programs, people, transactions, products, sales, testimonies, countdowns, logistics, schedules] = await Promise.all([
      db.events.toArray(), db.weeklyPrograms.toArray(), db.people.toArray(),
      db.transactions.toArray(), db.products.toArray(), db.sales.toArray(),
      db.testimonies.toArray(), db.countdowns.toArray(), db.logistics.toArray(),
      db.schedules.toArray(),
    ]);
    exportToJSON({ events, programs, people, transactions, products, sales, testimonies, countdowns, logistics, schedules, exportDate: new Date().toISOString() }, 'churchpro-backup');
  }

  async function clearAllData() {
    if (!confirm('⚠️ Supprimer TOUTES les données ? Cette action est irréversible !')) return;
    if (!confirm('Êtes-vous sûr ? Toutes vos données seront perdues.')) return;
    await Promise.all([
      db.events.clear(), db.weeklyPrograms.clear(), db.people.clear(),
      db.transactions.clear(), db.products.clear(), db.sales.clear(),
      db.testimonies.clear(), db.countdowns.clear(), db.logistics.clear(),
      db.schedules.clear(), db.stockMovements.clear(),
    ]);
    alert('✅ Toutes les données ont été supprimées.');
  }

  // Stats
  const eventCount    = useLiveQuery(() => db.events.count(), []) || 0;
  const peopleCount   = useLiveQuery(() => db.people.count(), []) || 0;
  const txCount       = useLiveQuery(() => db.transactions.count(), []) || 0;
  const productCount  = useLiveQuery(() => db.products.count(), []) || 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-bold text-white text-2xl">Paramètres</h1>
        <p className="text-gray-400 text-sm">Configuration de l'application</p>
      </div>

      {/* Church info */}
      <Card className="p-5">
        <h2 className="font-display font-bold text-white text-base mb-4 flex items-center gap-2"><Globe size={16} className="text-sky-400" />Informations de l'église</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input label="Nom de l'église" value={form.churchName} onChange={e => f('churchName', e.target.value)} placeholder="Mon Église" />
          <Input label="Ville" value={form.churchCity} onChange={e => f('churchCity', e.target.value)} placeholder="Ville" />
          <Select label="Devise" value={form.currency} onChange={e => f('currency', e.target.value)}
            options={[
              { value: 'XAF', label: 'XAF – Franc CFA (CEMAC)' },
              { value: 'XOF', label: 'XOF – Franc CFA (UEMOA)' },
              { value: 'EUR', label: 'EUR – Euro' },
              { value: 'USD', label: 'USD – Dollar américain' },
              { value: 'GBP', label: 'GBP – Livre sterling' },
              { value: 'NGN', label: 'NGN – Naira nigérian' },
              { value: 'KES', label: 'KES – Shilling kényan' },
              { value: 'ZAR', label: 'ZAR – Rand sud-africain' },
            ]} />
          <Select label="Langue" value={form.language} onChange={e => f('language', e.target.value)}
            options={[{ value: 'fr', label: '🇫🇷 Français' }, { value: 'en', label: '🇬🇧 English' }]} />
        </div>
        <Button className="mt-4" onClick={save}>{saved ? '✓ Enregistré !' : 'Enregistrer'}</Button>
      </Card>

      {/* Appearance */}
      <Card className="p-5">
        <h2 className="font-display font-bold text-white text-base mb-4 flex items-center gap-2">
          {theme === 'dark' ? <Moon size={16} className="text-violet-400" /> : <Sun size={16} className="text-amber-400" />}
          Apparence
        </h2>
        <div className="flex items-center justify-between p-3 rounded-xl bg-white/5">
          <div>
            <p className="font-semibold text-white text-sm">Mode {theme === 'dark' ? 'sombre' : 'clair'}</p>
            <p className="text-xs text-gray-400">Thème actuel de l'interface</p>
          </div>
          <button onClick={toggleTheme} className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${theme === 'dark' ? 'bg-primary-600' : 'bg-gray-500'}`}>
            <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${theme === 'dark' ? 'translate-x-6' : 'translate-x-1'}`} />
          </button>
        </div>
      </Card>

      {/* Notifications */}
      <Card className="p-5">
        <h2 className="font-display font-bold text-white text-base mb-4 flex items-center gap-2"><Bell size={16} className="text-amber-400" />Notifications</h2>
        <div className="flex items-center justify-between p-3 rounded-xl bg-white/5">
          <div>
            <p className="font-semibold text-white text-sm">Notifications activées</p>
            <p className="text-xs text-gray-400">Rappels pour les événements à venir</p>
          </div>
          <button onClick={() => f('notifications', !form.notifications)} className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${form.notifications ? 'bg-primary-600' : 'bg-gray-600'}`}>
            <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${form.notifications ? 'translate-x-6' : 'translate-x-1'}`} />
          </button>
        </div>
      </Card>

      {/* Data stats */}
      <Card className="p-5">
        <h2 className="font-display font-bold text-white text-base mb-4 flex items-center gap-2"><Database size={16} className="text-emerald-400" />Données stockées</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: 'Événements', value: eventCount, color: 'text-orange-400' },
            { label: 'Personnes', value: peopleCount, color: 'text-pink-400' },
            { label: 'Transactions', value: txCount, color: 'text-emerald-400' },
            { label: 'Produits', value: productCount, color: 'text-violet-400' },
          ].map(s => (
            <div key={s.label} className="bg-white/5 rounded-xl p-3 text-center">
              <p className={`font-display font-bold text-xl ${s.color}`}>{s.value}</p>
              <p className="text-xs text-gray-400">{s.label}</p>
            </div>
          ))}
        </div>
        <p className="text-xs text-gray-500 mt-3 text-center">Toutes les données sont stockées localement sur cet appareil (IndexedDB)</p>
      </Card>

      {/* Export / Import */}
      <Card className="p-5">
        <h2 className="font-display font-bold text-white text-base mb-4 flex items-center gap-2"><Download size={16} className="text-sky-400" />Sauvegarde & Restauration</h2>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 rounded-xl bg-white/5">
            <div>
              <p className="font-semibold text-white text-sm">Exporter toutes les données</p>
              <p className="text-xs text-gray-400">Télécharger un fichier JSON de sauvegarde</p>
            </div>
            <Button size="sm" variant="secondary" icon={<Download size={14} />} onClick={exportAllData}>Exporter</Button>
          </div>
          <div className="flex items-center justify-between p-3 rounded-xl bg-red-500/10 border border-red-500/20">
            <div>
              <p className="font-semibold text-red-300 text-sm">Supprimer toutes les données</p>
              <p className="text-xs text-red-400/70">Action irréversible. Faites d'abord une sauvegarde.</p>
            </div>
            <Button size="sm" variant="danger" icon={<Trash2 size={14} />} onClick={clearAllData}>Supprimer</Button>
          </div>
        </div>
      </Card>

      {/* App info */}
      <Card className="p-5">
        <h2 className="font-display font-bold text-white text-base mb-4 flex items-center gap-2"><Info size={16} className="text-gray-400" />À propos</h2>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between"><span className="text-gray-400">Application</span><span className="text-white font-bold">ChurchProGestion</span></div>
          <div className="flex justify-between"><span className="text-gray-400">Version</span><span className="text-white">1.0.0</span></div>
          <div className="flex justify-between"><span className="text-gray-400">Mode</span><span className="text-emerald-400">Hors ligne (PWA)</span></div>
          <div className="flex justify-between"><span className="text-gray-400">Stockage</span><span className="text-white">IndexedDB local</span></div>
          <div className="flex justify-between"><span className="text-gray-400">Stack</span><span className="text-white">React + TypeScript + Vite</span></div>
        </div>
        <p className="mt-4 text-xs text-gray-500 text-center leading-relaxed">
          Application de gestion pour organisations religieuses.<br />
          Données 100% privées, stockées uniquement sur votre appareil.
        </p>
      </Card>
    </div>
  );
}
