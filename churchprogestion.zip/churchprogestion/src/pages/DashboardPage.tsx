import { useLiveQuery } from 'dexie-react-hooks';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { Calendar, Users, DollarSign, Package, Flame, TrendingUp, Clock, AlertCircle } from 'lucide-react';
import { db } from '@/db';
import { Card, StatCard, EmptyState, ProgressBar, Badge } from '@/components/ui';
import { formatDate, formatCurrency, daysUntil, EVENT_TYPES, STATUS_COLORS, STATUS_LABELS } from '@/utils';
import { useAppStore } from '@/store';
import { CountdownMini } from './CountdownPage';

export function DashboardPage() {
  const { settings } = useAppStore();
  const currency = settings.currency || 'XAF';

  const events      = useLiveQuery(() => db.events.orderBy('startDate').toArray(), []) || [];
  const transactions = useLiveQuery(() => db.transactions.orderBy('date').reverse().limit(100).toArray(), []) || [];
  const people      = useLiveQuery(() => db.people.count(), []) || 0;
  const products    = useLiveQuery(() => db.products.count(), []) || 0;
  const countdowns  = useLiveQuery(() => db.countdowns.where('archived').equals(0).toArray(), []) || [];

  const upcoming = events.filter(e => new Date(e.startDate) > new Date() && e.status !== 'cancelled')
    .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime())
    .slice(0, 5);

  const totalIncome  = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const totalExpense = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);

  // Last 6 months financial data
  const now = new Date();
  const monthlyData = Array.from({ length: 6 }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
    const month = d.toLocaleString('fr-FR', { month: 'short' });
    const income  = transactions.filter(t => {
      const td = new Date(t.date);
      return t.type === 'income' && td.getMonth() === d.getMonth() && td.getFullYear() === d.getFullYear();
    }).reduce((s, t) => s + t.amount, 0);
    const expense = transactions.filter(t => {
      const td = new Date(t.date);
      return t.type === 'expense' && td.getMonth() === d.getMonth() && td.getFullYear() === d.getFullYear();
    }).reduce((s, t) => s + t.amount, 0);
    return { month, income, expense };
  });

  const eventsByType = Object.entries(
    events.reduce((acc, e) => { acc[e.type] = (acc[e.type] || 0) + 1; return acc; }, {} as Record<string, number>)
  ).map(([name, value]) => ({ name: EVENT_TYPES[name]?.split(' ')[1] || name, value }));

  const COLORS = ['#6366f1','#0ea5e9','#8b5cf6','#f59e0b','#10b981','#ef4444','#ec4899'];

  return (
    <div className="space-y-6">
      {/* ── HEADER ── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-white text-2xl">Tableau de bord</h1>
          <p className="text-gray-400 text-sm font-body mt-0.5">
            {settings.churchName} · {new Date().toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
      </div>

      {/* ── KPI CARDS ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Événements" value={events.length} icon={<Flame size={18} />} color="text-orange-400" />
        <StatCard label="Membres" value={people} icon={<Users size={18} />} color="text-pink-400" />
        <StatCard label="Revenus" value={formatCurrency(totalIncome, currency)} icon={<TrendingUp size={18} />} color="text-emerald-400" />
        <StatCard label="Dépenses" value={formatCurrency(totalExpense, currency)} icon={<DollarSign size={18} />} color="text-red-400" />
      </div>

      {/* ── FINANCE SUMMARY ── */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-bold text-white text-base">Finances – 6 derniers mois</h2>
        </div>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={monthlyData} barGap={4}>
            <XAxis dataKey="month" tick={{ fill: '#9ca3af', fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: '#9ca3af', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => v >= 1000 ? `${(v/1000).toFixed(0)}k` : v} />
            <Tooltip contentStyle={{ background: '#1a1a3e', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', color: '#fff' }} />
            <Bar dataKey="income"  name="Recettes"  fill="#10b981" radius={[6,6,0,0]} />
            <Bar dataKey="expense" name="Dépenses"  fill="#ef4444" radius={[6,6,0,0]} />
          </BarChart>
        </ResponsiveContainer>
        <div className="mt-3 flex gap-4">
          <div className="flex-1">
            <ProgressBar value={totalExpense} max={totalIncome || 1} color="bg-emerald-500" label="Taux de dépenses" showPercent />
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-400">Solde</p>
            <p className={`font-bold font-display text-sm ${totalIncome - totalExpense >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {formatCurrency(totalIncome - totalExpense, currency)}
            </p>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* ── UPCOMING EVENTS ── */}
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-4">
            <Calendar size={16} className="text-sky-400" />
            <h2 className="font-display font-bold text-white text-base">Événements à venir</h2>
          </div>
          {upcoming.length === 0 ? (
            <EmptyState icon="📅" title="Aucun événement" description="Ajoutez votre premier événement" />
          ) : (
            <div className="space-y-3">
              {upcoming.map(ev => {
                const days = daysUntil(ev.startDate);
                return (
                  <div key={ev.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/8 transition-colors">
                    <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: ev.color }} />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-white text-sm truncate">{ev.name}</p>
                      <p className="text-xs text-gray-400">{formatDate(ev.startDate)} · {ev.location}</p>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <Badge color={days <= 7 ? 'bg-red-500/20 text-red-400' : days <= 30 ? 'bg-amber-500/20 text-amber-400' : 'bg-sky-500/20 text-sky-400'}>
                        {days <= 0 ? "Aujourd'hui" : `J-${days}`}
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        {/* ── EVENTS BY TYPE PIE ── */}
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-4">
            <Flame size={16} className="text-orange-400" />
            <h2 className="font-display font-bold text-white text-base">Répartition des événements</h2>
          </div>
          {eventsByType.length === 0 ? (
            <EmptyState icon="📊" title="Aucune donnée" />
          ) : (
            <div className="flex items-center gap-4">
              <PieChart width={130} height={130}>
                <Pie data={eventsByType} cx={60} cy={60} innerRadius={35} outerRadius={60} dataKey="value" strokeWidth={0}>
                  {eventsByType.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
              </PieChart>
              <div className="flex-1 space-y-2">
                {eventsByType.map((item, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                    <span className="text-xs text-gray-300 flex-1">{item.name}</span>
                    <span className="text-xs font-bold text-white">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Card>
      </div>

      {/* ── COUNTDOWNS ── */}
      {countdowns.filter(c => c.isActive).length > 0 && (
        <div>
          <h2 className="font-display font-bold text-white text-base mb-3 flex items-center gap-2">
            <Clock size={16} className="text-red-400" /> Comptes à rebours actifs
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {countdowns.filter(c => c.isActive).slice(0, 3).map(c => (
              <CountdownMini key={c.id} countdown={c} />
            ))}
          </div>
        </div>
      )}

      {/* ── ALERTS ── */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <AlertCircle size={16} className="text-amber-400" />
          <h2 className="font-display font-bold text-white text-base">Alertes & rappels</h2>
        </div>
        <AlertsList events={upcoming} />
      </Card>
    </div>
  );
}

function AlertsList({ events }: { events: { id?: number; name: string; startDate: Date }[] }) {
  const alerts: { level: 'danger' | 'warning' | 'info'; msg: string }[] = [];
  events.forEach(e => {
    const d = daysUntil(e.startDate);
    if (d <= 3) alerts.push({ level: 'danger', msg: `${e.name} dans ${d <= 0 ? "moins d'1 jour" : `${d} jour(s)`}` });
    else if (d <= 7) alerts.push({ level: 'warning', msg: `${e.name} dans ${d} jours` });
    else if (d <= 15) alerts.push({ level: 'info', msg: `${e.name} dans ${d} jours` });
  });
  if (!alerts.length) return <p className="text-gray-400 text-sm font-body">Aucune alerte pour le moment.</p>;
  const colors = { danger: 'bg-red-500/10 border-red-500/30 text-red-300', warning: 'bg-amber-500/10 border-amber-500/30 text-amber-300', info: 'bg-sky-500/10 border-sky-500/30 text-sky-300' };
  return (
    <div className="space-y-2">
      {alerts.map((a, i) => (
        <div key={i} className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-sm ${colors[a.level]}`}>
          <AlertCircle size={14} /> {a.msg}
        </div>
      ))}
    </div>
  );
}
