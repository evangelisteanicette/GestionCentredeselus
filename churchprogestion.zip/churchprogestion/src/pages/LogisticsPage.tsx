import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Plus, Search, Truck, Package, Users, Home, Utensils, Mic } from 'lucide-react';
import { db } from '@/db';
import { Card, Button, Input, Select, Modal, Badge, EmptyState, Textarea } from '@/components/ui';
import { formatCurrency, cn } from '@/utils';
import type { LogisticsItem } from '@/types';

const CATEGORIES = [
  { value: 'transport',     label: 'Transport',     icon: '🚗' },
  { value: 'hebergement',   label: 'Hébergement',   icon: '🏨' },
  { value: 'restauration',  label: 'Restauration',  icon: '🍽️' },
  { value: 'benevole',      label: 'Bénévoles',     icon: '🙋' },
  { value: 'invite',        label: 'Invités',       icon: '👥' },
  { value: 'artiste',       label: 'Artistes',      icon: '🎤' },
  { value: 'orateur',       label: 'Orateurs',      icon: '🎙️' },
];

const STATUS_OPTS = [
  { value: 'pending',   label: 'En attente' },
  { value: 'confirmed', label: 'Confirmé' },
  { value: 'delivered', label: 'Livré / Présent' },
  { value: 'cancelled', label: 'Annulé' },
];

const STATUS_COLORS: Record<string, string> = {
  pending:   'bg-amber-500/20 text-amber-400',
  confirmed: 'bg-sky-500/20 text-sky-400',
  delivered: 'bg-emerald-500/20 text-emerald-400',
  cancelled: 'bg-red-500/20 text-red-400',
};

export function LogisticsPage() {
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<LogisticsItem | null>(null);
  const [form, setForm] = useState<Partial<LogisticsItem>>({ category: 'transport', status: 'pending', quantity: 1, cost: 0 });

  const items = useLiveQuery(() => db.logistics.orderBy('createdAt').reverse().toArray(), []) || [];
  const events = useLiveQuery(() => db.events.toArray(), []) || [];

  const filtered = items.filter(item => {
    const matchSearch = item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.contactName?.toLowerCase().includes(search.toLowerCase()) ||
      item.supplier?.toLowerCase().includes(search.toLowerCase());
    const matchCat = catFilter === 'all' || item.category === catFilter;
    return matchSearch && matchCat;
  });

  const totalCost = filtered.reduce((s, i) => s + (i.cost * i.quantity), 0);

  function openNew() {
    setEditing(null);
    setForm({ category: 'transport', status: 'pending', quantity: 1, cost: 0, currency: 'XAF' });
    setModalOpen(true);
  }
  function openEdit(item: LogisticsItem) { setEditing(item); setForm({ ...item }); setModalOpen(true); }

  async function save() {
    const now = new Date();
    if (editing?.id) {
      await db.logistics.update(editing.id, { ...form, updatedAt: now });
    } else {
      await db.logistics.add({ ...form, createdAt: now, updatedAt: now } as LogisticsItem);
    }
    setModalOpen(false);
  }

  async function remove(id: number) {
    if (confirm('Supprimer cet élément ?')) await db.logistics.delete(id);
  }

  const f = (k: string, v: unknown) => setForm(prev => ({ ...prev, [k]: v }));

  const catCounts = CATEGORIES.map(c => ({
    ...c,
    count: items.filter(i => i.category === c.value).length,
  }));

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-white text-2xl">Logistique</h1>
          <p className="text-gray-400 text-sm">{items.length} éléments · Coût total : {formatCurrency(items.reduce((s,i) => s + i.cost*i.quantity, 0))}</p>
        </div>
        <Button icon={<Plus size={16} />} onClick={openNew}>Ajouter</Button>
      </div>

      {/* Category filters */}
      <div className="flex gap-2 flex-wrap">
        <button onClick={() => setCatFilter('all')} className={cn('px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors', catFilter === 'all' ? 'bg-primary-600/30 border-primary-500/50 text-primary-300' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white')}>
          Tout ({items.length})
        </button>
        {catCounts.map(c => (
          <button key={c.value} onClick={() => setCatFilter(catFilter === c.value ? 'all' : c.value)}
            className={cn('px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors', catFilter === c.value ? 'bg-primary-600/30 border-primary-500/50 text-primary-300' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white')}>
            {c.icon} {c.label} {c.count > 0 && `(${c.count})`}
          </button>
        ))}
      </div>

      <Input placeholder="Rechercher…" value={search} onChange={e => setSearch(e.target.value)} icon={<Search size={14} />} />

      {filtered.length === 0 ? (
        <EmptyState icon={<Truck />} title="Aucun élément" description="Ajoutez des éléments logistiques" action={<Button size="sm" icon={<Plus size={14} />} onClick={openNew}>Ajouter</Button>} />
      ) : (
        <div className="space-y-2">
          {/* Summary bar */}
          {catFilter !== 'all' && (
            <div className="text-sm text-gray-400 font-body">
              {filtered.length} élément(s) · Total : <span className="text-emerald-400 font-bold">{formatCurrency(totalCost)}</span>
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {filtered.map(item => (
              <LogisticsCard key={item.id} item={item} onEdit={() => openEdit(item)} onDelete={() => remove(item.id!)} />
            ))}
          </div>
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Modifier' : 'Nouvel élément logistique'} size="lg">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input label="Nom *" value={form.name || ''} onChange={e => f('name', e.target.value)} placeholder="Ex: Bus 50 places" className="col-span-2" />
            <Select label="Catégorie" value={form.category || 'transport'} onChange={e => f('category', e.target.value)}
              options={CATEGORIES.map(c => ({ value: c.value, label: `${c.icon} ${c.label}` }))} />
            <Select label="Statut" value={form.status || 'pending'} onChange={e => f('status', e.target.value)} options={STATUS_OPTS} />
            <Input label="Quantité" type="number" min={1} value={form.quantity || 1} onChange={e => f('quantity', Number(e.target.value))} />
            <Input label="Unité" value={form.unit || ''} onChange={e => f('unit', e.target.value)} placeholder="Ex: places, repas…" />
            <Input label="Coût unitaire" type="number" value={form.cost || 0} onChange={e => f('cost', Number(e.target.value))} />
            <Select label="Devise" value={form.currency || 'XAF'} onChange={e => f('currency', e.target.value)}
              options={[{ value: 'XAF', label: 'XAF' }, { value: 'EUR', label: 'EUR' }, { value: 'USD', label: 'USD' }]} />
            <Input label="Fournisseur" value={form.supplier || ''} onChange={e => f('supplier', e.target.value)} placeholder="Nom du fournisseur" />
            <Input label="Contact" value={form.contactName || ''} onChange={e => f('contactName', e.target.value)} placeholder="Nom du contact" />
            <Input label="Téléphone contact" value={form.contactPhone || ''} onChange={e => f('contactPhone', e.target.value)} />
            <Select label="Événement associé" value={String(form.eventId || '')} onChange={e => f('eventId', e.target.value ? Number(e.target.value) : undefined)}
              options={[{ value: '', label: '— Aucun —' }, ...events.map(e => ({ value: String(e.id), label: e.name }))]} />
          </div>
          <Textarea label="Description / Notes" value={form.notes || ''} onChange={e => f('notes', e.target.value)} rows={3} />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Annuler</Button>
            <Button onClick={save} disabled={!form.name}>Enregistrer</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function LogisticsCard({ item, onEdit, onDelete }: { item: LogisticsItem; onEdit: () => void; onDelete: () => void }) {
  const cat = CATEGORIES.find(c => c.value === item.category);
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-start gap-3 flex-1 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-white/8 flex items-center justify-center text-lg flex-shrink-0">{cat?.icon || '📦'}</div>
          <div className="flex-1 min-w-0">
            <p className="font-display font-bold text-white text-sm truncate">{item.name}</p>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <Badge color={STATUS_COLORS[item.status]}>{STATUS_OPTS.find(s => s.value === item.status)?.label}</Badge>
              {item.quantity > 1 && <span className="text-xs text-gray-400">×{item.quantity} {item.unit}</span>}
            </div>
            {item.supplier && <p className="text-xs text-gray-500 mt-1">🏢 {item.supplier}</p>}
            {item.contactName && <p className="text-xs text-gray-500">👤 {item.contactName} {item.contactPhone && `· ${item.contactPhone}`}</p>}
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          {item.cost > 0 && (
            <p className="font-bold text-emerald-400 text-sm font-display">{formatCurrency(item.cost * item.quantity, item.currency)}</p>
          )}
          <div className="flex gap-1">
            <button onClick={onEdit} className="p-1 rounded text-gray-400 hover:text-sky-400 transition-colors text-xs">✏️</button>
            <button onClick={onDelete} className="p-1 rounded text-gray-400 hover:text-red-400 transition-colors text-xs">🗑️</button>
          </div>
        </div>
      </div>
    </Card>
  );
}
