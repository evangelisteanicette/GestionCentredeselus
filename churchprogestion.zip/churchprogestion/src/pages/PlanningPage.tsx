import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Plus, Clock3, ChevronLeft, ChevronRight, Trash2, Edit2 } from 'lucide-react';
import { db } from '@/db';
import { Card, Button, Input, Select, Modal, Badge, EmptyState, Textarea } from '@/components/ui';
import { formatDate, SCHEDULE_TYPES, generateId, cn } from '@/utils';
import type { DailySchedule, ScheduleItem } from '@/types';

const TYPE_OPTS = Object.entries(SCHEDULE_TYPES).map(([v, d]) => ({ value: v, label: d.label }));

export function PlanningPage() {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 10));
  const [modalOpen, setModalOpen] = useState(false);
  const [itemModalOpen, setItemModalOpen] = useState(false);
  const [editing, setEditing] = useState<DailySchedule | null>(null);
  const [editingItem, setEditingItem] = useState<{ scheduleId: number; item: ScheduleItem | null } | null>(null);
  const [scheduleForm, setScheduleForm] = useState({ title: '', eventId: '' });
  const [itemForm, setItemForm] = useState<Partial<ScheduleItem>>({ type: 'priere', time: '09:00', duration: 30, title: '', responsible: '', notes: '', color: '#6366f1' });

  const schedules = useLiveQuery(() => db.schedules.toArray(), []) || [];
  const events = useLiveQuery(() => db.events.toArray(), []) || [];

  const dateSchedules = schedules.filter(s => {
    const d = new Date(s.date);
    return d.toISOString().slice(0, 10) === selectedDate;
  });

  function prevDay() {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() - 1);
    setSelectedDate(d.toISOString().slice(0, 10));
  }
  function nextDay() {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + 1);
    setSelectedDate(d.toISOString().slice(0, 10));
  }

  async function saveSchedule() {
    const now = new Date();
    if (editing?.id) {
      await db.schedules.update(editing.id, { title: scheduleForm.title, eventId: scheduleForm.eventId ? Number(scheduleForm.eventId) : undefined, updatedAt: now });
    } else {
      await db.schedules.add({
        title: scheduleForm.title,
        date: new Date(selectedDate),
        eventId: scheduleForm.eventId ? Number(scheduleForm.eventId) : undefined,
        items: [],
        createdAt: now, updatedAt: now,
      });
    }
    setModalOpen(false);
  }

  async function saveItem() {
    if (!editingItem) return;
    const schedule = await db.schedules.get(editingItem.scheduleId);
    if (!schedule) return;
    const now = new Date();
    let items: ScheduleItem[];
    const newItem = { ...itemForm, id: editingItem.item?.id || generateId() } as ScheduleItem;
    if (editingItem.item) {
      items = schedule.items.map(i => i.id === editingItem.item!.id ? newItem : i);
    } else {
      items = [...schedule.items, newItem];
    }
    items.sort((a, b) => a.time.localeCompare(b.time));
    await db.schedules.update(editingItem.scheduleId, { items, updatedAt: now });
    setItemModalOpen(false);
  }

  async function deleteSchedule(id: number) {
    if (confirm('Supprimer ce planning ?')) await db.schedules.delete(id);
  }

  async function deleteItem(scheduleId: number, itemId: string) {
    const schedule = await db.schedules.get(scheduleId);
    if (!schedule) return;
    await db.schedules.update(scheduleId, { items: schedule.items.filter(i => i.id !== itemId), updatedAt: new Date() });
  }

  function openNewSchedule() {
    setEditing(null);
    setScheduleForm({ title: '', eventId: '' });
    setModalOpen(true);
  }

  function openNewItem(scheduleId: number) {
    setEditingItem({ scheduleId, item: null });
    setItemForm({ type: 'priere', time: '09:00', duration: 30, title: '', responsible: '', notes: '', color: '#6366f1' });
    setItemModalOpen(true);
  }

  function openEditItem(scheduleId: number, item: ScheduleItem) {
    setEditingItem({ scheduleId, item });
    setItemForm({ ...item });
    setItemModalOpen(true);
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-white text-2xl">Planning journalier</h1>
          <p className="text-gray-400 text-sm">Emplois du temps quotidiens</p>
        </div>
        <Button icon={<Plus size={16} />} onClick={openNewSchedule}>Nouveau planning</Button>
      </div>

      {/* Date navigation */}
      <div className="flex items-center gap-3">
        <button onClick={prevDay} className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors"><ChevronLeft size={16} /></button>
        <div className="flex-1">
          <Input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} />
        </div>
        <button onClick={nextDay} className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors"><ChevronRight size={16} /></button>
        <Button size="sm" variant="ghost" onClick={() => setSelectedDate(new Date().toISOString().slice(0, 10))}>Aujourd'hui</Button>
      </div>

      {dateSchedules.length === 0 ? (
        <EmptyState icon={<Clock3 />} title={`Aucun planning pour le ${formatDate(selectedDate)}`} description="Créez un emploi du temps pour cette journée"
          action={<Button size="sm" icon={<Plus size={14} />} onClick={openNewSchedule}>Créer</Button>} />
      ) : (
        <div className="space-y-4">
          {dateSchedules.map(schedule => (
            <ScheduleCard key={schedule.id} schedule={schedule} events={events}
              onNewItem={() => openNewItem(schedule.id!)}
              onEditItem={(item) => openEditItem(schedule.id!, item)}
              onDeleteItem={(itemId) => deleteItem(schedule.id!, itemId)}
              onDelete={() => deleteSchedule(schedule.id!)}
            />
          ))}
        </div>
      )}

      {/* Schedule Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Modifier le planning' : 'Nouveau planning'}>
        <div className="space-y-4">
          <Input label="Titre du planning *" value={scheduleForm.title} onChange={e => setScheduleForm(f => ({ ...f, title: e.target.value }))} placeholder="Ex: Programme Culte du Dimanche" />
          <Select label="Événement associé (optionnel)" value={scheduleForm.eventId} onChange={e => setScheduleForm(f => ({ ...f, eventId: e.target.value }))}
            options={[{ value: '', label: '— Aucun —' }, ...events.map(e => ({ value: String(e.id), label: e.name }))]} />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Annuler</Button>
            <Button onClick={saveSchedule} disabled={!scheduleForm.title}>Créer</Button>
          </div>
        </div>
      </Modal>

      {/* Item Modal */}
      <Modal open={itemModalOpen} onClose={() => setItemModalOpen(false)} title={editingItem?.item ? 'Modifier l\'activité' : 'Nouvelle activité'}>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input label="Heure" type="time" value={itemForm.time || '09:00'} onChange={e => setItemForm(f => ({ ...f, time: e.target.value }))} />
            <Input label="Durée (min)" type="number" min={5} step={5} value={itemForm.duration || 30} onChange={e => setItemForm(f => ({ ...f, duration: Number(e.target.value) }))} />
          </div>
          <Select label="Type" value={itemForm.type || 'priere'} onChange={e => setItemForm(f => ({ ...f, type: e.target.value as any }))} options={TYPE_OPTS} />
          <Input label="Titre *" value={itemForm.title || ''} onChange={e => setItemForm(f => ({ ...f, title: e.target.value }))} placeholder="Ex: Louange d'ouverture" />
          <Input label="Responsable" value={itemForm.responsible || ''} onChange={e => setItemForm(f => ({ ...f, responsible: e.target.value }))} placeholder="Nom du responsable" />
          <div className="flex items-center gap-3">
            <label className="text-sm text-gray-300">Couleur :</label>
            <input type="color" value={itemForm.color || '#6366f1'} onChange={e => setItemForm(f => ({ ...f, color: e.target.value }))} className="w-10 h-8 rounded cursor-pointer bg-transparent border-0" />
          </div>
          <Textarea label="Notes" value={itemForm.notes || ''} onChange={e => setItemForm(f => ({ ...f, notes: e.target.value }))} rows={2} />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setItemModalOpen(false)}>Annuler</Button>
            <Button onClick={saveItem} disabled={!itemForm.title}>Enregistrer</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function ScheduleCard({ schedule, events, onNewItem, onEditItem, onDeleteItem, onDelete }: {
  schedule: DailySchedule; events: any[];
  onNewItem: () => void; onEditItem: (item: ScheduleItem) => void;
  onDeleteItem: (id: string) => void; onDelete: () => void;
}) {
  const linkedEvent = events.find(e => e.id === schedule.eventId);
  const totalMinutes = schedule.items.reduce((s, i) => s + i.duration, 0);
  const hours = Math.floor(totalMinutes / 60);
  const mins = totalMinutes % 60;

  return (
    <Card className="p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-display font-bold text-white text-base">{schedule.title}</h3>
          {linkedEvent && <p className="text-xs text-sky-400 mt-0.5">📌 {linkedEvent.name}</p>}
          <p className="text-xs text-gray-400 mt-0.5">{schedule.items.length} activité(s) · {hours > 0 ? `${hours}h` : ''}{mins > 0 ? `${mins}min` : ''} total</p>
        </div>
        <div className="flex gap-2">
          <Button size="xs" variant="secondary" icon={<Plus size={12} />} onClick={onNewItem}>Activité</Button>
          <button onClick={onDelete} className="p-1.5 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"><Trash2 size={14} /></button>
        </div>
      </div>

      {schedule.items.length === 0 ? (
        <p className="text-gray-500 text-sm text-center py-4">Aucune activité — cliquez "Activité" pour en ajouter</p>
      ) : (
        <div className="space-y-2 relative">
          {/* Timeline line */}
          <div className="absolute left-[29px] top-4 bottom-4 w-px bg-white/10" />
          {schedule.items.map((item, idx) => {
            const typeInfo = SCHEDULE_TYPES[item.type] || SCHEDULE_TYPES.autre;
            return (
              <div key={item.id} className="flex gap-3 items-start relative animate-fade-in" style={{ animationDelay: `${idx * 50}ms` }}>
                {/* Time dot */}
                <div className="flex-shrink-0 w-[58px] text-right">
                  <span className="text-xs font-mono text-gray-400">{item.time}</span>
                </div>
                <div className="w-3 h-3 rounded-full flex-shrink-0 mt-1 border-2 border-surface-dark z-10" style={{ background: item.color || typeInfo.color }} />
                <div className="flex-1 min-w-0 p-3 rounded-xl border border-white/8 hover:border-white/15 transition-colors" style={{ borderLeftColor: item.color || typeInfo.color, borderLeftWidth: '3px' }}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge color="bg-white/10 text-gray-300 text-xs">{typeInfo.label}</Badge>
                        <span className="text-xs text-gray-500">{item.duration} min</span>
                      </div>
                      <p className="font-semibold text-white text-sm mt-1">{item.title}</p>
                      {item.responsible && <p className="text-xs text-gray-400">👤 {item.responsible}</p>}
                      {item.notes && <p className="text-xs text-gray-500 mt-1 italic">{item.notes}</p>}
                    </div>
                    <div className="flex gap-1 flex-shrink-0">
                      <button onClick={() => onEditItem(item)} className="p-1 rounded text-gray-400 hover:text-sky-400 transition-colors"><Edit2 size={12} /></button>
                      <button onClick={() => onDeleteItem(item.id)} className="p-1 rounded text-gray-400 hover:text-red-400 transition-colors"><Trash2 size={12} /></button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}
