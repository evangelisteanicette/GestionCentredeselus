import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Plus, Search, Flame, MapPin, Calendar, User, Edit2, Trash2, ChevronDown, ChevronUp } from 'lucide-react';
import { db } from '@/db';
import { Card, Button, Input, Select, Modal, Badge, EmptyState, Textarea } from '@/components/ui';
import { formatDate, formatCurrency, daysUntil, EVENT_TYPES, STATUS_COLORS, STATUS_LABELS, generateId, cn } from '@/utils';
import type { ChurchEvent, EventType, EventStatus } from '@/types';

const BLANK_SECTION = () => ({ responsible: '', notes: '', tasks: [], completed: false });

function blankEvent(): Omit<ChurchEvent, 'id' | 'createdAt' | 'updatedAt'> {
  return {
    name: '', type: 'conference', location: '', status: 'planned',
    startDate: new Date(), endDate: new Date(), startTime: '09:00', endTime: '17:00',
    responsible: '', budget: 0, description: '', color: '#6366f1',
    authorizations: BLANK_SECTION(), communication: BLANK_SECTION(),
    publicRelations: BLANK_SECTION(), security: BLANK_SECTION(),
    medical: BLANK_SECTION(), media: BLANK_SECTION(),
    equipment: BLANK_SECTION(), logistics: BLANK_SECTION(),
  };
}

export function EventsPage() {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<ChurchEvent | null>(null);
  const [form, setForm] = useState(blankEvent());
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const events = useLiveQuery(() => db.events.orderBy('startDate').toArray(), []) || [];

  const filtered = events.filter(e => {
    const matchSearch = e.name.toLowerCase().includes(search.toLowerCase()) || e.location.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' || e.status === filter || e.type === filter;
    return matchSearch && matchFilter;
  });

  function openNew() { setEditing(null); setForm(blankEvent()); setModalOpen(true); }
  function openEdit(e: ChurchEvent) { setEditing(e); setForm({ ...e }); setModalOpen(true); }

  async function save() {
    const now = new Date();
    if (editing?.id) {
      await db.events.update(editing.id, { ...form, updatedAt: now });
    } else {
      await db.events.add({ ...form, createdAt: now, updatedAt: now } as ChurchEvent);
    }
    setModalOpen(false);
  }

  async function remove(id: number) {
    if (confirm('Supprimer cet événement ?')) await db.events.delete(id);
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-white text-2xl">Événements & Croisades</h1>
          <p className="text-gray-400 text-sm">{events.length} événement(s) au total</p>
        </div>
        <Button icon={<Plus size={16} />} onClick={openNew}>Nouveau</Button>
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="flex-1 min-w-0 max-w-xs">
          <Input placeholder="Rechercher…" value={search} onChange={e => setSearch(e.target.value)} icon={<Search size={14} />} />
        </div>
        <Select
          className="w-44"
          value={filter}
          onChange={e => setFilter(e.target.value)}
          options={[
            { value: 'all', label: 'Tous les statuts' },
            { value: 'planned', label: 'Planifié' },
            { value: 'in-progress', label: 'En cours' },
            { value: 'completed', label: 'Terminé' },
            ...Object.entries(EVENT_TYPES).map(([v, l]) => ({ value: v, label: l })),
          ]}
        />
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={<Flame />} title="Aucun événement trouvé" description="Créez votre premier événement" action={<Button onClick={openNew} icon={<Plus size={14} />} size="sm">Créer</Button>} />
      ) : (
        <div className="space-y-3">
          {filtered.map(ev => (
            <EventCard
              key={ev.id}
              event={ev}
              expanded={expandedId === ev.id}
              onToggle={() => setExpandedId(expandedId === ev.id ? null : ev.id!)}
              onEdit={() => openEdit(ev)}
              onDelete={() => remove(ev.id!)}
            />
          ))}
        </div>
      )}

      {/* Form Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Modifier l\'événement' : 'Nouvel événement'} size="xl">
        <EventForm form={form} setForm={setForm} onSave={save} onCancel={() => setModalOpen(false)} />
      </Modal>
    </div>
  );
}

function EventCard({ event: ev, expanded, onToggle, onEdit, onDelete }: {
  event: ChurchEvent; expanded: boolean;
  onToggle: () => void; onEdit: () => void; onDelete: () => void;
}) {
  const days = daysUntil(ev.startDate);
  const sections = [
    { key: 'authorizations', label: '📋 Autorisations' },
    { key: 'communication', label: '📢 Communication' },
    { key: 'publicRelations', label: '🤝 Relations pub.' },
    { key: 'security', label: '🛡️ Sécurité' },
    { key: 'medical', label: '⚕️ Médical' },
    { key: 'media', label: '📹 Médias' },
    { key: 'equipment', label: '🔧 Équipements' },
    { key: 'logistics', label: '🚛 Logistique' },
  ] as const;

  return (
    <Card className="overflow-hidden">
      <div className="h-1" style={{ background: ev.color }} />
      <div className="p-4">
        <div className="flex items-start gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h3 className="font-display font-bold text-white text-base">{ev.name}</h3>
              <Badge color={STATUS_COLORS[ev.status]}>{STATUS_LABELS[ev.status]}</Badge>
              <Badge color="bg-white/10 text-gray-300">{EVENT_TYPES[ev.type]}</Badge>
            </div>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-gray-400">
              <span className="flex items-center gap-1"><MapPin size={12} />{ev.location}</span>
              <span className="flex items-center gap-1"><Calendar size={12} />{formatDate(ev.startDate)}</span>
              <span className="flex items-center gap-1"><User size={12} />{ev.responsible}</span>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            {days > 0 && <Badge color={days <= 7 ? 'bg-red-500/20 text-red-400' : 'bg-sky-500/20 text-sky-400'}>J-{days}</Badge>}
            <button onClick={onEdit} className="p-1.5 rounded-lg text-gray-400 hover:text-sky-400 hover:bg-sky-500/10 transition-colors"><Edit2 size={14} /></button>
            <button onClick={onDelete} className="p-1.5 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"><Trash2 size={14} /></button>
            <button onClick={onToggle} className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-colors">
              {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>
          </div>
        </div>

        {expanded && (
          <div className="mt-4 pt-4 border-t border-white/10 space-y-3 animate-fade-in">
            {ev.description && <p className="text-sm text-gray-300">{ev.description}</p>}
            {ev.budget > 0 && (
              <div className="flex items-center gap-2 text-sm">
                <span className="text-gray-400">Budget :</span>
                <span className="font-bold text-emerald-400">{formatCurrency(ev.budget)}</span>
              </div>
            )}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {sections.map(s => {
                const sec = (ev as any)[s.key];
                return (
                  <div key={s.key} className={cn('p-2.5 rounded-xl text-xs', sec?.completed ? 'bg-emerald-500/10 border border-emerald-500/20' : 'bg-white/5 border border-white/10')}>
                    <p className="font-semibold text-white mb-0.5">{s.label}</p>
                    {sec?.responsible && <p className="text-gray-400 truncate">{sec.responsible}</p>}
                    <p className={cn('font-bold mt-1', sec?.completed ? 'text-emerald-400' : 'text-gray-500')}>
                      {sec?.completed ? '✓ OK' : 'En cours'}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}

function EventForm({ form, setForm, onSave, onCancel }: {
  form: any; setForm: (f: any) => void; onSave: () => void; onCancel: () => void;
}) {
  const f = (field: string, value: unknown) => setForm({ ...form, [field]: value });
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input label="Nom de l'événement *" value={form.name} onChange={e => f('name', e.target.value)} placeholder="Ex: Grande Croisade 2025" />
        <Select label="Type" value={form.type} onChange={e => f('type', e.target.value)}
          options={Object.entries(EVENT_TYPES).map(([v, l]) => ({ value: v, label: l }))} />
        <Input label="Lieu *" value={form.location} onChange={e => f('location', e.target.value)} placeholder="Ex: Stade Municipal" />
        <Input label="Responsable" value={form.responsible} onChange={e => f('responsible', e.target.value)} placeholder="Nom du responsable" />
        <Input label="Date de début" type="date" value={form.startDate instanceof Date ? form.startDate.toISOString().slice(0,10) : String(form.startDate).slice(0,10)} onChange={e => f('startDate', new Date(e.target.value))} />
        <Input label="Date de fin" type="date" value={form.endDate instanceof Date ? form.endDate.toISOString().slice(0,10) : String(form.endDate).slice(0,10)} onChange={e => f('endDate', new Date(e.target.value))} />
        <Input label="Heure début" type="time" value={form.startTime} onChange={e => f('startTime', e.target.value)} />
        <Input label="Heure fin" type="time" value={form.endTime} onChange={e => f('endTime', e.target.value)} />
        <Input label="Budget (XAF)" type="number" value={form.budget} onChange={e => f('budget', Number(e.target.value))} />
        <Select label="Statut" value={form.status} onChange={e => f('status', e.target.value)}
          options={[
            { value: 'draft', label: 'Brouillon' }, { value: 'planned', label: 'Planifié' },
            { value: 'in-progress', label: 'En cours' }, { value: 'completed', label: 'Terminé' },
            { value: 'cancelled', label: 'Annulé' },
          ]} />
      </div>
      <div className="flex items-center gap-3">
        <label className="text-sm text-gray-300">Couleur :</label>
        <input type="color" value={form.color} onChange={e => f('color', e.target.value)} className="w-10 h-8 rounded cursor-pointer bg-transparent border-0" />
      </div>
      <Textarea label="Description" value={form.description} onChange={e => f('description', e.target.value)} placeholder="Description de l'événement…" />

      <div className="flex justify-end gap-3 pt-2">
        <Button variant="secondary" onClick={onCancel}>Annuler</Button>
        <Button onClick={onSave} disabled={!form.name || !form.location}>Enregistrer</Button>
      </div>
    </div>
  );
}
