import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Plus, Calendar, ChevronLeft, ChevronRight, Edit2, Trash2 } from 'lucide-react';
import { db } from '@/db';
import { Card, Button, Input, Select, Modal, Badge, EmptyState, Textarea, Tabs, ProgressBar } from '@/components/ui';
import { getWeekNumber, getWeekDates, formatDate, generateId, cn } from '@/utils';
import type { WeeklyProgram } from '@/types';

const STATUS_OPTS = [
  { value: 'planned', label: 'Planifié' },
  { value: 'in-progress', label: 'En cours' },
  { value: 'completed', label: 'Terminé' },
  { value: 'cancelled', label: 'Annulé' },
];

const STATUS_COLORS: Record<string, string> = {
  planned: 'bg-sky-500/20 text-sky-400',
  'in-progress': 'bg-amber-500/20 text-amber-400',
  completed: 'bg-emerald-500/20 text-emerald-400',
  cancelled: 'bg-red-500/20 text-red-400',
};

export function ProgrammingPage() {
  const year = new Date().getFullYear();
  const [tab, setTab] = useState('week');
  const [currentWeek, setCurrentWeek] = useState(getWeekNumber());
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<WeeklyProgram | null>(null);
  const [form, setForm] = useState<Partial<WeeklyProgram>>({});

  const programs = useLiveQuery(() => db.weeklyPrograms.where('year').equals(year).toArray(), [year]) || [];

  const weekMap = new Map(programs.map(p => [p.weekNumber, p]));

  function openNew(weekNumber?: number) {
    setEditing(null);
    setForm({ weekNumber: weekNumber || currentWeek, year, status: 'planned', activities: [], theme: '', spiritualObjectives: '', numericalObjectives: '', responsible: '', indicators: '', report: '', notes: '' });
    setModalOpen(true);
  }
  function openEdit(p: WeeklyProgram) { setEditing(p); setForm({ ...p }); setModalOpen(true); }

  async function save() {
    const now = new Date();
    if (editing?.id) {
      await db.weeklyPrograms.update(editing.id, { ...form, updatedAt: now });
    } else {
      await db.weeklyPrograms.add({ ...form, createdAt: now, updatedAt: now } as WeeklyProgram);
    }
    setModalOpen(false);
  }

  async function remove(id: number) {
    if (confirm('Supprimer cette semaine ?')) await db.weeklyPrograms.delete(id);
  }

  const completedCount = programs.filter(p => p.status === 'completed').length;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-white text-2xl">Programmation Annuelle {year}</h1>
          <p className="text-gray-400 text-sm">{programs.length}/54 semaines planifiées</p>
        </div>
        <Button icon={<Plus size={16} />} onClick={() => openNew()}>Ajouter</Button>
      </div>

      <ProgressBar value={completedCount} max={54} color="bg-primary-500" label={`${completedCount} semaines complétées`} showPercent />

      <Tabs
        tabs={[
          { id: 'week', label: 'Semaine' },
          { id: 'month', label: 'Mois' },
          { id: 'quarter', label: 'Trimestre' },
          { id: 'year', label: 'Année' },
        ]}
        active={tab}
        onChange={setTab}
      />

      {tab === 'week' && (
        <WeekView
          currentWeek={currentWeek}
          year={year}
          weekMap={weekMap}
          onPrev={() => setCurrentWeek(w => Math.max(1, w - 1))}
          onNext={() => setCurrentWeek(w => Math.min(54, w + 1))}
          onNew={openNew}
          onEdit={openEdit}
          onDelete={remove}
        />
      )}
      {tab === 'month' && <MonthView programs={programs} year={year} onEdit={openEdit} onDelete={remove} onNew={openNew} />}
      {tab === 'quarter' && <QuarterView programs={programs} year={year} onEdit={openEdit} onDelete={remove} onNew={openNew} />}
      {tab === 'year' && <YearView programs={programs} weekMap={weekMap} onNew={openNew} onEdit={openEdit} />}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Modifier la semaine' : 'Nouvelle semaine'} size="lg">
        <WeekForm form={form} setForm={f => setForm(prev => ({ ...prev, ...f }))} onSave={save} onCancel={() => setModalOpen(false)} />
      </Modal>
    </div>
  );
}

function WeekView({ currentWeek, year, weekMap, onPrev, onNext, onNew, onEdit, onDelete }: any) {
  const prog = weekMap.get(currentWeek);
  const { start, end } = getWeekDates(currentWeek, year);
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <button onClick={onPrev} className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors"><ChevronLeft size={16} /></button>
        <div className="text-center">
          <p className="font-display font-bold text-white">Semaine {currentWeek}</p>
          <p className="text-sm text-gray-400">{formatDate(start)} – {formatDate(end)}</p>
        </div>
        <button onClick={onNext} className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors"><ChevronRight size={16} /></button>
      </div>
      {prog ? (
        <WeekCard prog={prog} onEdit={onEdit} onDelete={onDelete} />
      ) : (
        <Card className="p-8">
          <EmptyState icon={<Calendar />} title={`Semaine ${currentWeek} non planifiée`} description="Cliquez pour ajouter les détails de cette semaine" action={<Button size="sm" icon={<Plus size={14} />} onClick={() => onNew(currentWeek)}>Planifier</Button>} />
        </Card>
      )}
    </div>
  );
}

function WeekCard({ prog, onEdit, onDelete }: { prog: WeeklyProgram; onEdit: (p: WeeklyProgram) => void; onDelete: (id: number) => void }) {
  return (
    <Card className="p-5 space-y-4">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-display font-bold text-white text-lg">{prog.theme || 'Sans thème'}</h3>
            <Badge color={STATUS_COLORS[prog.status]}>{prog.status}</Badge>
          </div>
          <p className="text-sm text-gray-400">Responsable : {prog.responsible || 'Non défini'}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => onEdit(prog)} className="p-2 rounded-lg text-gray-400 hover:text-sky-400 hover:bg-sky-500/10 transition-colors"><Edit2 size={14} /></button>
          <button onClick={() => onDelete(prog.id!)} className="p-2 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"><Trash2 size={14} /></button>
        </div>
      </div>
      {prog.spiritualObjectives && (
        <div className="p-3 rounded-xl bg-violet-500/10 border border-violet-500/20">
          <p className="text-xs font-semibold text-violet-300 mb-1">Objectifs spirituels</p>
          <p className="text-sm text-gray-300">{prog.spiritualObjectives}</p>
        </div>
      )}
      {prog.numericalObjectives && (
        <div className="p-3 rounded-xl bg-sky-500/10 border border-sky-500/20">
          <p className="text-xs font-semibold text-sky-300 mb-1">Objectifs numériques</p>
          <p className="text-sm text-gray-300">{prog.numericalObjectives}</p>
        </div>
      )}
      {prog.activities?.length > 0 && (
        <div>
          <p className="text-xs font-semibold text-gray-400 mb-2">Activités ({prog.activities.length})</p>
          <div className="space-y-1">
            {prog.activities.map(a => (
              <div key={a.id} className="flex items-center gap-2 text-sm text-gray-300 p-2 rounded-lg bg-white/5">
                <span className="text-primary-400 font-mono text-xs">{a.time}</span>
                <span className="flex-1">{a.name}</span>
                <span className="text-gray-500 text-xs">{a.responsible}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      {prog.report && (
        <div className="p-3 rounded-xl bg-white/5">
          <p className="text-xs font-semibold text-gray-400 mb-1">Rapport</p>
          <p className="text-sm text-gray-300">{prog.report}</p>
        </div>
      )}
    </Card>
  );
}

function MonthView({ programs, year, onEdit, onDelete, onNew }: any) {
  const months = Array.from({ length: 12 }, (_, i) => {
    const weeksInMonth = programs.filter((p: WeeklyProgram) => {
      const { start } = getWeekDates(p.weekNumber, year);
      return start.getMonth() === i;
    });
    return { month: i, name: new Date(year, i, 1).toLocaleString('fr-FR', { month: 'long' }), weeks: weeksInMonth };
  });
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {months.map(({ month, name, weeks }) => (
        <Card key={month} className="p-4">
          <h3 className="font-display font-bold text-white capitalize mb-3">{name}</h3>
          {weeks.length === 0 ? (
            <p className="text-gray-500 text-sm">Non planifié</p>
          ) : (
            <div className="space-y-2">
              {weeks.map((w: WeeklyProgram) => (
                <div key={w.id} className="flex items-center justify-between text-sm p-2 rounded-lg bg-white/5">
                  <span className="text-gray-300">S{w.weekNumber} – {w.theme || 'Sans thème'}</span>
                  <Badge color={STATUS_COLORS[w.status]}>{w.status.slice(0, 4)}.</Badge>
                </div>
              ))}
            </div>
          )}
        </Card>
      ))}
    </div>
  );
}

function QuarterView({ programs, year, onEdit, onDelete, onNew }: any) {
  const quarters = [
    { label: 'T1 – Jan–Mar', weeks: [1,13] },
    { label: 'T2 – Avr–Juin', weeks: [14,26] },
    { label: 'T3 – Juil–Sep', weeks: [27,39] },
    { label: 'T4 – Oct–Déc', weeks: [40,54] },
  ];
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {quarters.map(q => {
        const qProgs = programs.filter((p: WeeklyProgram) => p.weekNumber >= q.weeks[0] && p.weekNumber <= q.weeks[1]);
        const completed = qProgs.filter((p: WeeklyProgram) => p.status === 'completed').length;
        const total = q.weeks[1] - q.weeks[0] + 1;
        return (
          <Card key={q.label} className="p-5">
            <h3 className="font-display font-bold text-white mb-2">{q.label}</h3>
            <ProgressBar value={completed} max={total} showPercent label={`${qProgs.length}/${total} semaines`} />
            <div className="mt-3 space-y-1">
              {qProgs.slice(0, 5).map((p: WeeklyProgram) => (
                <div key={p.id} className="flex items-center gap-2 text-xs text-gray-300 p-1.5 rounded bg-white/5">
                  <span className="text-primary-400">S{p.weekNumber}</span>
                  <span className="flex-1 truncate">{p.theme || 'Sans thème'}</span>
                </div>
              ))}
              {qProgs.length > 5 && <p className="text-xs text-gray-500 text-center">+{qProgs.length - 5} autres</p>}
            </div>
          </Card>
        );
      })}
    </div>
  );
}

function YearView({ programs, weekMap, onNew, onEdit }: any) {
  return (
    <div className="grid grid-cols-6 sm:grid-cols-9 gap-1.5">
      {Array.from({ length: 54 }, (_, i) => {
        const w = i + 1;
        const prog = weekMap.get(w);
        const colors: Record<string, string> = {
          planned: 'bg-sky-500/40 border-sky-500/50',
          'in-progress': 'bg-amber-500/40 border-amber-500/50',
          completed: 'bg-emerald-500/40 border-emerald-500/50',
          cancelled: 'bg-red-500/20 border-red-500/30',
        };
        return (
          <button
            key={w}
            onClick={() => prog ? onEdit(prog) : onNew(w)}
            className={cn(
              'aspect-square rounded-lg border text-xs font-mono font-bold transition-all hover:scale-110',
              prog ? colors[prog.status] : 'bg-white/5 border-white/10 text-gray-500 hover:bg-white/10'
            )}
            title={prog ? `S${w}: ${prog.theme}` : `Semaine ${w} (cliquer pour ajouter)`}
          >
            {w}
          </button>
        );
      })}
    </div>
  );
}

function WeekForm({ form, setForm, onSave, onCancel }: any) {
  const [activities, setActivities] = useState(form.activities || []);
  const f = (k: string, v: unknown) => setForm({ [k]: v });
  function addActivity() {
    const act = { id: generateId(), name: '', time: '09:00', duration: 60, responsible: '', description: '' };
    const updated = [...activities, act];
    setActivities(updated);
    f('activities', updated);
  }
  function updateActivity(idx: number, field: string, value: string) {
    const updated = activities.map((a: any, i: number) => i === idx ? { ...a, [field]: value } : a);
    setActivities(updated);
    f('activities', updated);
  }
  function removeActivity(idx: number) {
    const updated = activities.filter((_: any, i: number) => i !== idx);
    setActivities(updated);
    f('activities', updated);
  }
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Input label="Numéro de semaine" type="number" min={1} max={54} value={form.weekNumber} onChange={e => f('weekNumber', Number(e.target.value))} />
        <Select label="Statut" value={form.status} onChange={e => f('status', e.target.value)} options={STATUS_OPTS} />
      </div>
      <Input label="Thème de la semaine" value={form.theme} onChange={e => f('theme', e.target.value)} placeholder="Ex: La foi qui déplace les montagnes" />
      <Input label="Responsable" value={form.responsible} onChange={e => f('responsible', e.target.value)} />
      <Textarea label="Objectifs spirituels" value={form.spiritualObjectives} onChange={e => f('spiritualObjectives', e.target.value)} />
      <Textarea label="Objectifs numériques" value={form.numericalObjectives} onChange={e => f('numericalObjectives', e.target.value)} />
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="text-sm font-semibold text-gray-300">Activités</label>
          <Button size="xs" variant="secondary" icon={<Plus size={12} />} onClick={addActivity}>Ajouter</Button>
        </div>
        <div className="space-y-2">
          {activities.map((a: any, i: number) => (
            <div key={a.id} className="flex gap-2 items-center p-2 rounded-xl bg-white/5">
              <input type="time" value={a.time} onChange={e => updateActivity(i, 'time', e.target.value)} className="bg-transparent text-white text-xs border-0 outline-none w-20" />
              <input value={a.name} onChange={e => updateActivity(i, 'name', e.target.value)} placeholder="Activité…" className="flex-1 bg-transparent text-white text-sm border-0 outline-none" />
              <input value={a.responsible} onChange={e => updateActivity(i, 'responsible', e.target.value)} placeholder="Responsable" className="w-28 bg-transparent text-gray-400 text-xs border-0 outline-none" />
              <button onClick={() => removeActivity(i)} className="text-red-400 hover:text-red-300 text-xs">✕</button>
            </div>
          ))}
        </div>
      </div>
      <Textarea label="Rapport" value={form.report} onChange={e => f('report', e.target.value)} placeholder="Rapport de la semaine…" />
      <div className="flex justify-end gap-3">
        <Button variant="secondary" onClick={onCancel}>Annuler</Button>
        <Button onClick={onSave}>Enregistrer</Button>
      </div>
    </div>
  );
}
