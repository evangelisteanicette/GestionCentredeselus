import { useState, useEffect, useCallback } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Plus, Timer, Archive, Bell, BellOff, Trash2 } from 'lucide-react';
import { db } from '@/db';
import { Card, Button, Input, Modal, Badge, EmptyState } from '@/components/ui';
import { formatDate, daysUntil, cn } from '@/utils';
import type { Countdown } from '@/types';

function useCountdownTimer(targetDate: Date) {
  const [remaining, setRemaining] = useState(calcRemaining(targetDate));
  useEffect(() => {
    const interval = setInterval(() => setRemaining(calcRemaining(targetDate)), 1000);
    return () => clearInterval(interval);
  }, [targetDate]);
  return remaining;
}

function calcRemaining(target: Date) {
  const diff = new Date(target).getTime() - Date.now();
  if (diff <= 0) return { days: 0, hours: 0, minutes: 0, seconds: 0, expired: true, total: 0 };
  const days    = Math.floor(diff / 86400000);
  const hours   = Math.floor((diff % 86400000) / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  const seconds = Math.floor((diff % 60000) / 1000);
  return { days, hours, minutes, seconds, expired: false, total: diff };
}

const MILESTONE_DAYS = [30, 15, 7, 3, 1];

export function CountdownPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({ name: '', targetDate: '', color: '#6366f1', notificationsEnabled: true });
  const [showArchived, setShowArchived] = useState(false);

  const countdowns = useLiveQuery(() => db.countdowns.orderBy('targetDate').toArray(), []) || [];

  const active   = countdowns.filter(c => !c.archived);
  const archived = countdowns.filter(c => c.archived);

  async function save() {
    const now = new Date();
    await db.countdowns.add({
      name: form.name,
      targetDate: new Date(form.targetDate),
      color: form.color,
      isActive: true,
      notificationsEnabled: form.notificationsEnabled,
      notificationsSent: [],
      archived: false,
      createdAt: now, updatedAt: now,
    });
    setModalOpen(false);
    setForm({ name: '', targetDate: '', color: '#6366f1', notificationsEnabled: true });
  }

  async function archive(id: number) { await db.countdowns.update(id, { archived: true, updatedAt: new Date() }); }
  async function remove(id: number) { if (confirm('Supprimer ?')) await db.countdowns.delete(id); }
  async function toggleNotif(id: number, current: boolean) { await db.countdowns.update(id, { notificationsEnabled: !current, updatedAt: new Date() }); }

  // Auto-archive expired
  useEffect(() => {
    const checkExpired = async () => {
      const all = await db.countdowns.where('archived').equals(0).toArray();
      for (const c of all) {
        if (new Date(c.targetDate) <= new Date()) {
          await db.countdowns.update(c.id!, { archived: true, updatedAt: new Date() });
        }
      }
    };
    const interval = setInterval(checkExpired, 60000);
    checkExpired();
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-white text-2xl">Comptes à rebours</h1>
          <p className="text-gray-400 text-sm">{active.length} actif(s)</p>
        </div>
        <Button icon={<Plus size={16} />} onClick={() => setModalOpen(true)}>Nouveau</Button>
      </div>

      {active.length === 0 ? (
        <EmptyState icon={<Timer />} title="Aucun compte à rebours" description="Créez un compte à rebours pour suivre vos événements" action={<Button size="sm" icon={<Plus size={14} />} onClick={() => setModalOpen(true)}>Créer</Button>} />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {active.map(c => (
            <CountdownCard key={c.id} countdown={c} onArchive={() => archive(c.id!)} onDelete={() => remove(c.id!)} onToggleNotif={() => toggleNotif(c.id!, c.notificationsEnabled)} />
          ))}
        </div>
      )}

      {archived.length > 0 && (
        <div>
          <button onClick={() => setShowArchived(v => !v)} className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors mb-3">
            <Archive size={14} /> {showArchived ? 'Masquer' : 'Afficher'} les archivés ({archived.length})
          </button>
          {showArchived && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {archived.map(c => (
                <Card key={c.id} className="p-4 opacity-50">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-bold text-white text-sm">{c.name}</p>
                      <p className="text-xs text-gray-400">{formatDate(c.targetDate)}</p>
                    </div>
                    <Badge color="bg-gray-500/20 text-gray-400">Expiré</Badge>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Nouveau compte à rebours">
        <div className="space-y-4">
          <Input label="Nom de l'événement *" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Ex: Grande Croisade" />
          <Input label="Date cible *" type="datetime-local" value={form.targetDate} onChange={e => setForm(f => ({ ...f, targetDate: e.target.value }))} />
          <div className="flex items-center gap-3">
            <label className="text-sm text-gray-300">Couleur :</label>
            <input type="color" value={form.color} onChange={e => setForm(f => ({ ...f, color: e.target.value }))} className="w-10 h-8 rounded cursor-pointer bg-transparent border-0" />
          </div>
          <div className="flex items-center gap-2">
            <input type="checkbox" id="notif" checked={form.notificationsEnabled} onChange={e => setForm(f => ({ ...f, notificationsEnabled: e.target.checked }))} className="w-4 h-4 accent-primary-600" />
            <label htmlFor="notif" className="text-sm text-gray-300">Activer les notifications</label>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Annuler</Button>
            <Button onClick={save} disabled={!form.name || !form.targetDate}>Créer</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function CountdownCard({ countdown: c, onArchive, onDelete, onToggleNotif }: { countdown: Countdown; onArchive: () => void; onDelete: () => void; onToggleNotif: () => void }) {
  const remaining = useCountdownTimer(c.targetDate);
  const totalDays = Math.max(1, daysUntil(c.targetDate));
  const elapsed = Math.max(0, 1 - remaining.total / (totalDays * 86400000));
  const pct = Math.min(100, Math.round(elapsed * 100));

  const urgency = remaining.days <= 1 ? 'text-red-400' : remaining.days <= 7 ? 'text-amber-400' : 'text-white';

  return (
    <Card className="p-5 relative overflow-hidden">
      {/* Color accent */}
      <div className="absolute top-0 left-0 right-0 h-1" style={{ background: c.color }} />
      <div className="absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl opacity-10" style={{ background: c.color, transform: 'translate(30%, -30%)' }} />

      <div className="relative">
        <div className="flex items-start justify-between mb-3">
          <h3 className="font-display font-bold text-white text-base pr-2">{c.name}</h3>
          <div className="flex gap-1 flex-shrink-0">
            <button onClick={onToggleNotif} className={cn('p-1.5 rounded-lg transition-colors', c.notificationsEnabled ? 'text-primary-400 hover:bg-primary-500/10' : 'text-gray-500 hover:bg-white/10')}>
              {c.notificationsEnabled ? <Bell size={13} /> : <BellOff size={13} />}
            </button>
            <button onClick={onArchive} className="p-1.5 rounded-lg text-gray-500 hover:text-amber-400 hover:bg-amber-500/10 transition-colors"><Archive size={13} /></button>
            <button onClick={onDelete} className="p-1.5 rounded-lg text-gray-500 hover:text-red-400 hover:bg-red-500/10 transition-colors"><Trash2 size={13} /></button>
          </div>
        </div>

        <p className="text-xs text-gray-400 mb-4">📅 {formatDate(c.targetDate)}</p>

        {/* Countdown digits */}
        <div className="flex justify-between gap-2 mb-4">
          {[
            { val: remaining.days, label: 'jours' },
            { val: remaining.hours, label: 'heures' },
            { val: remaining.minutes, label: 'min' },
            { val: remaining.seconds, label: 'sec' },
          ].map(({ val, label }) => (
            <div key={label} className="flex-1 text-center">
              <div className="relative">
                <div className="w-full aspect-square rounded-xl flex items-center justify-center bg-white/8 border border-white/10" style={{ boxShadow: `0 0 15px ${c.color}30` }}>
                  <span className={cn('font-mono font-bold text-xl', urgency, 'animate-countdown')}>{String(val).padStart(2, '0')}</span>
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-1">{label}</p>
            </div>
          ))}
        </div>

        {/* Progress arc */}
        <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-1000"
            style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${c.color}aa, ${c.color})` }}
          />
        </div>
        <div className="flex justify-between mt-1">
          <span className="text-xs text-gray-500">Début</span>
          <span className="text-xs text-gray-400">{pct}% écoulé</span>
          <span className="text-xs text-gray-500">J-0</span>
        </div>

        {/* Urgency badge */}
        {remaining.days <= 7 && !remaining.expired && (
          <div className="mt-3 p-2 rounded-lg bg-red-500/10 border border-red-500/20 text-center">
            <p className="text-xs font-bold text-red-400">
              {remaining.days === 0 ? "🔥 C'est aujourd'hui !" : `⚡ Plus que ${remaining.days} jour(s) !`}
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}

// Mini version for dashboard
export function CountdownMini({ countdown: c }: { countdown: Countdown }) {
  const remaining = useCountdownTimer(c.targetDate);
  return (
    <Card className="p-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-0.5" style={{ background: c.color }} />
      <p className="font-display font-bold text-white text-sm mb-2">{c.name}</p>
      <div className="flex gap-2 text-center">
        {[{ val: remaining.days, label: 'j' }, { val: remaining.hours, label: 'h' }, { val: remaining.minutes, label: 'm' }, { val: remaining.seconds, label: 's' }].map(({ val, label }) => (
          <div key={label} className="flex-1">
            <div className="bg-white/10 rounded-lg py-1.5 font-mono font-bold text-white text-sm">{String(val).padStart(2, '0')}</div>
            <p className="text-xs text-gray-500 mt-0.5">{label}</p>
          </div>
        ))}
      </div>
    </Card>
  );
}
