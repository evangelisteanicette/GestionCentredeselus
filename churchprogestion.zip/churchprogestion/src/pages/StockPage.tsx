import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Plus, Search, Package, ShoppingCart, AlertTriangle, BarChart2, Download } from 'lucide-react';
import { db } from '@/db';
import { Card, Button, Input, Select, Modal, Badge, EmptyState, Textarea, StatCard, Tabs, ProgressBar } from '@/components/ui';
import { formatCurrency, formatDate, exportToCSV, cn } from '@/utils';
import type { Product, Sale, ProductCategory } from '@/types';
import { useAppStore } from '@/store';

const CATEGORIES: Record<ProductCategory, { label: string; emoji: string }> = {
  livre:     { label: 'Livre',              emoji: '📚' },
  brochure:  { label: 'Brochure',           emoji: '📄' },
  numerique: { label: 'Support numérique',  emoji: '💿' },
  audio:     { label: 'Audio',              emoji: '🎵' },
  video:     { label: 'Vidéo',              emoji: '🎬' },
  autre:     { label: 'Autre',              emoji: '📦' },
};

export function StockPage() {
  const { settings } = useAppStore();
  const currency = settings.currency || 'XAF';
  const [tab, setTab] = useState('products');
  const [search, setSearch] = useState('');
  const [productModal, setProductModal] = useState(false);
  const [saleModal, setSaleModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productForm, setProductForm] = useState<Partial<Product>>({ category: 'livre', price: 0, cost: 0, stock: 0, minStock: 5, isActive: true, currency });
  const [saleForm, setSaleForm] = useState<Partial<Sale>>({ quantity: 1, paymentMethod: 'cash', date: new Date() });

  const products = useLiveQuery(() => db.products.orderBy('name').toArray(), []) || [];
  const sales    = useLiveQuery(() => db.sales.orderBy('date').reverse().toArray(), []) || [];
  const events   = useLiveQuery(() => db.events.toArray(), []) || [];

  const filtered = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.author?.toLowerCase().includes(search.toLowerCase()));

  const totalRevenue    = sales.reduce((s, sale) => s + sale.totalPrice, 0);
  const totalItems      = sales.reduce((s, sale) => s + sale.quantity, 0);
  const lowStockCount   = products.filter(p => p.stock <= p.minStock && p.isActive).length;
  const stockValue      = products.reduce((s, p) => s + p.cost * p.stock, 0);

  async function saveProduct() {
    const now = new Date();
    if (editingProduct?.id) {
      await db.products.update(editingProduct.id, { ...productForm, updatedAt: now });
    } else {
      await db.products.add({ ...productForm, createdAt: now, updatedAt: now } as Product);
    }
    setProductModal(false);
  }

  async function saveSale() {
    const product = await db.products.get(Number(saleForm.productId));
    if (!product) return;
    const now = new Date();
    const total = (saleForm.quantity || 1) * (saleForm.unitPrice || product.price);
    await db.sales.add({ ...saleForm, productName: product.name, unitPrice: saleForm.unitPrice || product.price, totalPrice: total, currency: product.currency, date: saleForm.date || now, createdAt: now, updatedAt: now } as Sale);
    // Decrease stock
    await db.products.update(Number(saleForm.productId), { stock: Math.max(0, product.stock - (saleForm.quantity || 1)), updatedAt: now });
    // Record stock movement
    await db.stockMovements.add({ productId: Number(saleForm.productId), type: 'out', quantity: saleForm.quantity || 1, reason: 'Vente', date: now, reference: '', createdAt: now, updatedAt: now });
    setSaleModal(false);
    setSaleForm({ quantity: 1, paymentMethod: 'cash', date: new Date() });
  }

  async function deleteProduct(id: number) {
    if (confirm('Supprimer ce produit ?')) await db.products.delete(id);
  }

  function openEditProduct(p: Product) {
    setEditingProduct(p);
    setProductForm({ ...p });
    setProductModal(true);
  }

  function openNewSale(p?: Product) {
    setSaleForm({ quantity: 1, paymentMethod: 'cash', date: new Date(), productId: p?.id, unitPrice: p?.price });
    setSaleModal(true);
  }

  const pf = (k: string, v: unknown) => setProductForm(prev => ({ ...prev, [k]: v }));
  const sf = (k: string, v: unknown) => setSaleForm(prev => ({ ...prev, [k]: v }));

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-white text-2xl">Stock & Ventes</h1>
          <p className="text-gray-400 text-sm">{products.length} produit(s) · {sales.length} vente(s)</p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" icon={<ShoppingCart size={14} />} onClick={() => openNewSale()}>Vente</Button>
          <Button icon={<Plus size={16} />} onClick={() => { setEditingProduct(null); setProductForm({ category: 'livre', price: 0, cost: 0, stock: 0, minStock: 5, isActive: true, currency }); setProductModal(true); }}>Produit</Button>
        </div>
      </div>

      {/* KPI */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Chiffre d'affaires" value={formatCurrency(totalRevenue, currency)} icon={<BarChart2 size={18} />} color="text-emerald-400" />
        <StatCard label="Articles vendus" value={totalItems} icon={<ShoppingCart size={18} />} color="text-sky-400" />
        <StatCard label="Valeur du stock" value={formatCurrency(stockValue, currency)} icon={<Package size={18} />} color="text-violet-400" />
        <StatCard label="Ruptures proches" value={lowStockCount} icon={<AlertTriangle size={18} />} color={lowStockCount > 0 ? 'text-amber-400' : 'text-gray-400'} />
      </div>

      {lowStockCount > 0 && (
        <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center gap-2">
          <AlertTriangle size={14} className="text-amber-400" />
          <p className="text-sm text-amber-300">{lowStockCount} produit(s) en rupture de stock ou stock faible</p>
        </div>
      )}

      <Tabs
        tabs={[{ id: 'products', label: '📦 Produits' }, { id: 'sales', label: '💳 Ventes' }]}
        active={tab}
        onChange={setTab}
      />

      {tab === 'products' && (
        <>
          <Input placeholder="Rechercher un produit…" value={search} onChange={e => setSearch(e.target.value)} icon={<Search size={14} />} />
          {filtered.length === 0 ? (
            <EmptyState icon={<Package />} title="Aucun produit" description="Ajoutez vos livres, brochures et supports" action={<Button size="sm" icon={<Plus size={14} />} onClick={() => setProductModal(true)}>Ajouter</Button>} />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {filtered.map(p => (
                <ProductCard key={p.id} product={p} currency={currency} onEdit={() => openEditProduct(p)} onDelete={() => deleteProduct(p.id!)} onSell={() => openNewSale(p)} />
              ))}
            </div>
          )}
        </>
      )}

      {tab === 'sales' && (
        <>
          <div className="flex justify-end">
            <Button variant="secondary" size="sm" icon={<Download size={14} />} onClick={() => exportToCSV(sales.map(s => ({ Date: formatDate(s.date), Produit: s.productName, Quantité: s.quantity, 'Prix unitaire': s.unitPrice, Total: s.totalPrice, Acheteur: s.buyerName, Paiement: s.paymentMethod })), 'ventes')}>Exporter</Button>
          </div>
          {sales.length === 0 ? (
            <EmptyState icon={<ShoppingCart />} title="Aucune vente" description="Enregistrez vos ventes" />
          ) : (
            <div className="space-y-2">
              {sales.map(sale => (
                <Card key={sale.id} className="p-3 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
                    <ShoppingCart size={14} className="text-emerald-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-white text-sm truncate">{sale.productName}</p>
                    <p className="text-xs text-gray-400">{formatDate(sale.date)} · {sale.buyerName || 'Anonyme'} · ×{sale.quantity}</p>
                  </div>
                  <p className="font-bold font-display text-emerald-400">{formatCurrency(sale.totalPrice, sale.currency)}</p>
                </Card>
              ))}
            </div>
          )}
        </>
      )}

      {/* Product Modal */}
      <Modal open={productModal} onClose={() => setProductModal(false)} title={editingProduct ? 'Modifier le produit' : 'Nouveau produit'} size="lg">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input label="Nom *" value={productForm.name || ''} onChange={e => pf('name', e.target.value)} className="col-span-2" />
            <Select label="Catégorie" value={productForm.category || 'livre'} onChange={e => pf('category', e.target.value)}
              options={Object.entries(CATEGORIES).map(([v, d]) => ({ value: v, label: `${d.emoji} ${d.label}` }))} />
            <Input label="Auteur" value={productForm.author || ''} onChange={e => pf('author', e.target.value)} />
            <Input label="Prix de vente" type="number" value={productForm.price || 0} onChange={e => pf('price', Number(e.target.value))} />
            <Input label="Coût d'achat" type="number" value={productForm.cost || 0} onChange={e => pf('cost', Number(e.target.value))} />
            <Input label="Stock actuel" type="number" value={productForm.stock || 0} onChange={e => pf('stock', Number(e.target.value))} />
            <Input label="Stock minimum" type="number" value={productForm.minStock || 5} onChange={e => pf('minStock', Number(e.target.value))} />
            <Input label="Code-barres" value={productForm.barcode || ''} onChange={e => pf('barcode', e.target.value)} className="col-span-2" />
          </div>
          <Textarea label="Description" value={productForm.description || ''} onChange={e => pf('description', e.target.value)} rows={2} />
          <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
            <input type="checkbox" checked={!!productForm.isActive} onChange={e => pf('isActive', e.target.checked)} className="w-4 h-4 accent-primary-600" />
            Produit actif
          </label>
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setProductModal(false)}>Annuler</Button>
            <Button onClick={saveProduct} disabled={!productForm.name}>Enregistrer</Button>
          </div>
        </div>
      </Modal>

      {/* Sale Modal */}
      <Modal open={saleModal} onClose={() => setSaleModal(false)} title="Enregistrer une vente">
        <div className="space-y-4">
          <Select label="Produit *" value={String(saleForm.productId || '')} onChange={e => { const p = products.find(p => p.id === Number(e.target.value)); sf('productId', Number(e.target.value)); if (p) sf('unitPrice', p.price); }}
            options={[{ value: '', label: '— Sélectionner —' }, ...products.filter(p => p.isActive && p.stock > 0).map(p => ({ value: String(p.id), label: `${p.name} (stock: ${p.stock})` }))]} />
          <div className="grid grid-cols-2 gap-4">
            <Input label="Quantité" type="number" min={1} value={saleForm.quantity || 1} onChange={e => sf('quantity', Number(e.target.value))} />
            <Input label="Prix unitaire" type="number" value={saleForm.unitPrice || 0} onChange={e => sf('unitPrice', Number(e.target.value))} />
            <Input label="Acheteur (nom)" value={saleForm.buyerName || ''} onChange={e => sf('buyerName', e.target.value)} />
            <Select label="Paiement" value={saleForm.paymentMethod || 'cash'} onChange={e => sf('paymentMethod', e.target.value)}
              options={[{ value: 'cash', label: 'Espèces' }, { value: 'transfer', label: 'Virement' }, { value: 'mobile', label: 'Mobile Money' }, { value: 'other', label: 'Autre' }]} />
            <Input label="Date" type="date" value={saleForm.date instanceof Date ? saleForm.date.toISOString().slice(0,10) : String(saleForm.date || '').slice(0,10)} onChange={e => sf('date', new Date(e.target.value))} className="col-span-2" />
          </div>
          {saleForm.productId && saleForm.quantity && saleForm.unitPrice && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center">
              <p className="text-sm text-gray-300">Total : <span className="font-bold text-emerald-400 text-lg">{formatCurrency(saleForm.quantity * saleForm.unitPrice, currency)}</span></p>
            </div>
          )}
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setSaleModal(false)}>Annuler</Button>
            <Button onClick={saveSale} disabled={!saleForm.productId || !saleForm.quantity}>Valider</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function ProductCard({ product: p, currency, onEdit, onDelete, onSell }: { product: Product; currency: string; onEdit: () => void; onDelete: () => void; onSell: () => void }) {
  const cat = CATEGORIES[p.category];
  const isLow = p.stock <= p.minStock;
  const margin = p.price > 0 ? Math.round(((p.price - p.cost) / p.price) * 100) : 0;
  return (
    <Card className="p-4">
      <div className="flex items-start gap-3 mb-3">
        <div className="w-10 h-10 rounded-xl bg-white/8 flex items-center justify-center text-xl flex-shrink-0">{cat.emoji}</div>
        <div className="flex-1 min-w-0">
          <p className="font-display font-bold text-white text-sm truncate">{p.name}</p>
          {p.author && <p className="text-xs text-gray-400">{p.author}</p>}
          <Badge color="bg-white/10 text-gray-300">{cat.label}</Badge>
        </div>
        <div className="flex gap-1 flex-shrink-0">
          <button onClick={onEdit} className="p-1 rounded text-gray-400 hover:text-sky-400 transition-colors text-xs">✏️</button>
          <button onClick={onDelete} className="p-1 rounded text-gray-400 hover:text-red-400 transition-colors text-xs">🗑️</button>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-2 mb-3 text-center">
        <div className="bg-white/5 rounded-lg p-2">
          <p className="text-xs text-gray-400">Prix</p>
          <p className="font-bold text-white text-sm">{formatCurrency(p.price, p.currency)}</p>
        </div>
        <div className={cn('rounded-lg p-2', isLow ? 'bg-red-500/10' : 'bg-white/5')}>
          <p className="text-xs text-gray-400">Stock</p>
          <p className={cn('font-bold text-sm', isLow ? 'text-red-400' : 'text-white')}>{p.stock}</p>
        </div>
        <div className="bg-white/5 rounded-lg p-2">
          <p className="text-xs text-gray-400">Marge</p>
          <p className="font-bold text-emerald-400 text-sm">{margin}%</p>
        </div>
      </div>
      <ProgressBar value={p.stock} max={Math.max(p.stock, p.minStock * 3)} color={isLow ? 'bg-red-500' : 'bg-emerald-500'} />
      <Button size="sm" variant="secondary" className="w-full mt-3" icon={<ShoppingCart size={13} />} onClick={onSell} disabled={p.stock === 0}>
        {p.stock === 0 ? 'Rupture de stock' : 'Enregistrer vente'}
      </Button>
    </Card>
  );
}
