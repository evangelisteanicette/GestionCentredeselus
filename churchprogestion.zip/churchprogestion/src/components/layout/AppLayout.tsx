import React, { useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Calendar, Flame, Truck, Clock3, Users, DollarSign,
  MessageSquare, Package, Timer, Brain, Settings, Menu, X, ChevronRight,
  Bell, Sun, Moon, Download
} from 'lucide-react';
import { useAppStore } from '@/store';
import { cn } from '@/utils';

const NAV_ITEMS = [
  { to: '/',            icon: LayoutDashboard, label: 'Tableau de bord', color: 'text-sky-400' },
  { to: '/programmation', icon: Calendar,       label: 'Programmation',   color: 'text-violet-400' },
  { to: '/evenements',  icon: Flame,            label: 'Événements',      color: 'text-orange-400' },
  { to: '/logistique',  icon: Truck,            label: 'Logistique',      color: 'text-emerald-400' },
  { to: '/planning',    icon: Clock3,           label: 'Planning journalier', color: 'text-yellow-400' },
  { to: '/rh',          icon: Users,            label: 'Ressources humaines', color: 'text-pink-400' },
  { to: '/finances',    icon: DollarSign,       label: 'Finances',        color: 'text-green-400' },
  { to: '/temoignages', icon: MessageSquare,    label: 'Témoignages',     color: 'text-purple-400' },
  { to: '/stock',       icon: Package,          label: 'Stock & Ventes',  color: 'text-amber-400' },
  { to: '/countdown',   icon: Timer,            label: 'Comptes à rebours', color: 'text-red-400' },
  { to: '/assistant',   icon: Brain,            label: 'Assistant IA',    color: 'text-teal-400' },
  { to: '/parametres',  icon: Settings,         label: 'Paramètres',      color: 'text-gray-400' },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const { sidebarOpen, setSidebarOpen, theme, toggleTheme, isInstallable, deferredPrompt } = useAppStore();
  const location = useLocation();

  // Close sidebar on route change (mobile)
  useEffect(() => { setSidebarOpen(false); }, [location.pathname, setSidebarOpen]);

  // Apply theme class
  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  async function handleInstall() {
    if (!deferredPrompt) return;
    await (deferredPrompt as any).prompt();
  }

  return (
    <div className={cn('flex h-screen bg-surface-dark overflow-hidden font-body', theme)}>
      {/* ── SIDEBAR ── */}
      <aside className={cn(
        'fixed inset-y-0 left-0 z-40 flex flex-col w-64 transition-transform duration-300 ease-in-out',
        'bg-surface-card border-r border-white/10',
        sidebarOpen ? 'translate-x-0' : '-translate-x-full',
        'lg:relative lg:translate-x-0'
      )}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-5 border-b border-white/10">
          <div className="w-9 h-9 rounded-xl bg-gradient-sky flex items-center justify-center text-white font-bold text-sm font-display">
            CPG
          </div>
          <div>
            <p className="font-display font-bold text-white text-sm leading-tight">ChurchPro</p>
            <p className="text-xs text-gray-400 leading-tight">Gestion</p>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="ml-auto lg:hidden text-gray-400 hover:text-white">
            <X size={18} />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-0.5 scrollbar-thin">
          {NAV_ITEMS.map(({ to, icon: Icon, label, color }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              className={({ isActive }) => cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all duration-150',
                isActive
                  ? 'bg-primary-600/20 text-white border border-primary-500/30'
                  : 'text-gray-400 hover:bg-white/8 hover:text-white'
              )}
            >
              {({ isActive }) => (
                <>
                  <Icon size={17} className={isActive ? 'text-primary-400' : color} />
                  <span className="flex-1">{label}</span>
                  {isActive && <ChevronRight size={14} className="text-primary-400" />}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        {/* Bottom actions */}
        <div className="p-3 border-t border-white/10 flex gap-2">
          <button onClick={toggleTheme} className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-gray-400 text-xs">
            {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
            {theme === 'dark' ? 'Clair' : 'Sombre'}
          </button>
          {isInstallable && (
            <button onClick={handleInstall} className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-primary-600/30 hover:bg-primary-600/50 transition-colors text-primary-300 text-xs">
              <Download size={15} />
              Installer
            </button>
          )}
        </div>
      </aside>

      {/* ── BACKDROP ── */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* ── MAIN ── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="flex items-center gap-3 px-4 py-3 border-b border-white/10 bg-surface-card/50 backdrop-blur-sm">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden text-gray-400 hover:text-white transition-colors p-1.5 rounded-lg hover:bg-white/10"
          >
            <Menu size={20} />
          </button>
          <div className="flex-1 min-w-0">
            <PageTitle />
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-white/10 transition-all relative">
              <Bell size={18} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
            </button>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6 bg-surface-dark">
          <div className="max-w-7xl mx-auto animate-fade-in">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}

function PageTitle() {
  const location = useLocation();
  const item = NAV_ITEMS.find(n => n.to === location.pathname || (n.to !== '/' && location.pathname.startsWith(n.to)));
  if (!item) return null;
  const Icon = item.icon;
  return (
    <div className="flex items-center gap-2">
      <Icon size={16} className={item.color} />
      <span className="font-display font-semibold text-white text-sm truncate">{item.label}</span>
    </div>
  );
}
