import React from 'react';
import { cn } from '@/utils';

// ─── BUTTON ───────────────────────────────────────────────────────────────────
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'success';
  size?: 'xs' | 'sm' | 'md' | 'lg';
  loading?: boolean;
  icon?: React.ReactNode;
}
export function Button({ variant = 'primary', size = 'md', loading, icon, children, className, disabled, ...props }: ButtonProps) {
  const base = 'inline-flex items-center gap-2 font-display font-semibold rounded-xl transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-transparent disabled:opacity-50 disabled:cursor-not-allowed active:scale-95';
  const variants = {
    primary:   'bg-primary-600 hover:bg-primary-500 text-white focus:ring-primary-500 shadow-glow-primary',
    secondary: 'bg-white/10 hover:bg-white/20 text-white border border-white/20 focus:ring-white/40',
    ghost:     'hover:bg-white/10 text-gray-300 hover:text-white focus:ring-white/20',
    danger:    'bg-red-600 hover:bg-red-500 text-white focus:ring-red-500',
    success:   'bg-emerald-600 hover:bg-emerald-500 text-white focus:ring-emerald-500',
  };
  const sizes = {
    xs: 'px-2.5 py-1.5 text-xs',
    sm: 'px-3 py-2 text-sm',
    md: 'px-4 py-2.5 text-sm',
    lg: 'px-6 py-3 text-base',
  };
  return (
    <button className={cn(base, variants[variant], sizes[size], className)} disabled={disabled || loading} {...props}>
      {loading ? <Spinner size="sm" /> : icon}
      {children}
    </button>
  );
}

// ─── BADGE ────────────────────────────────────────────────────────────────────
interface BadgeProps { children: React.ReactNode; color?: string; className?: string }
export function Badge({ children, color, className }: BadgeProps) {
  return (
    <span className={cn('inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold font-body', color || 'bg-primary-500/20 text-primary-300', className)}>
      {children}
    </span>
  );
}

// ─── CARD ─────────────────────────────────────────────────────────────────────
interface CardProps { children: React.ReactNode; className?: string; glass?: boolean; onClick?: () => void }
export function Card({ children, className, glass, onClick }: CardProps) {
  return (
    <div
      onClick={onClick}
      className={cn(
        'rounded-2xl border transition-all duration-200',
        glass
          ? 'bg-white/5 backdrop-blur-md border-white/10 hover:bg-white/8'
          : 'bg-surface-card border-white/10',
        onClick && 'cursor-pointer hover:border-primary-500/50',
        'shadow-card-dark',
        className
      )}
    >
      {children}
    </div>
  );
}

// ─── INPUT ────────────────────────────────────────────────────────────────────
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  icon?: React.ReactNode;
}
export function Input({ label, error, icon, className, ...props }: InputProps) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-sm font-semibold text-gray-300 font-body">{label}</label>}
      <div className="relative">
        {icon && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">{icon}</span>}
        <input
          className={cn(
            'w-full rounded-xl bg-white/5 border border-white/15 text-white placeholder-gray-500 font-body text-sm',
            'px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500/50',
            'transition-all duration-200',
            icon && 'pl-10',
            error && 'border-red-500/50 focus:ring-red-500/50',
            className
          )}
          {...props}
        />
      </div>
      {error && <p className="text-xs text-red-400 font-body">{error}</p>}
    </div>
  );
}

// ─── TEXTAREA ─────────────────────────────────────────────────────────────────
interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string; error?: string;
}
export function Textarea({ label, error, className, ...props }: TextareaProps) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-sm font-semibold text-gray-300 font-body">{label}</label>}
      <textarea
        className={cn(
          'w-full rounded-xl bg-white/5 border border-white/15 text-white placeholder-gray-500 font-body text-sm',
          'px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500/50',
          'transition-all duration-200 resize-none',
          error && 'border-red-500/50', className
        )}
        rows={4}
        {...props}
      />
      {error && <p className="text-xs text-red-400 font-body">{error}</p>}
    </div>
  );
}

// ─── SELECT ───────────────────────────────────────────────────────────────────
interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string; error?: string; options: { value: string; label: string }[];
}
export function Select({ label, error, options, className, ...props }: SelectProps) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-sm font-semibold text-gray-300 font-body">{label}</label>}
      <select
        className={cn(
          'w-full rounded-xl bg-surface-card border border-white/15 text-white font-body text-sm',
          'px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500/50',
          'transition-all duration-200',
          error && 'border-red-500/50', className
        )}
        {...props}
      >
        {options.map(o => <option key={o.value} value={o.value} className="bg-surface-card">{o.label}</option>)}
      </select>
      {error && <p className="text-xs text-red-400 font-body">{error}</p>}
    </div>
  );
}

// ─── MODAL ────────────────────────────────────────────────────────────────────
interface ModalProps { open: boolean; onClose: () => void; title: string; children: React.ReactNode; size?: 'sm' | 'md' | 'lg' | 'xl' }
export function Modal({ open, onClose, title, children, size = 'md' }: ModalProps) {
  if (!open) return null;
  const sizes = { sm: 'max-w-sm', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div
        className={cn('relative w-full rounded-2xl bg-surface-card border border-white/10 shadow-2xl animate-slide-up', sizes[size])}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <h2 className="font-display font-bold text-white text-lg">{title}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors text-2xl leading-none">&times;</button>
        </div>
        <div className="px-6 py-5 max-h-[75vh] overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

// ─── SPINNER ──────────────────────────────────────────────────────────────────
export function Spinner({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const s = { sm: 'h-4 w-4', md: 'h-6 w-6', lg: 'h-8 w-8' };
  return <div className={cn('border-2 border-white/20 border-t-white rounded-full animate-spin', s[size])} />;
}

// ─── EMPTY STATE ──────────────────────────────────────────────────────────────
interface EmptyStateProps { icon?: React.ReactNode; title: string; description?: string; action?: React.ReactNode }
export function EmptyState({ icon, title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      {icon && <div className="text-5xl mb-4 opacity-40">{icon}</div>}
      <h3 className="font-display font-bold text-gray-300 text-lg mb-1">{title}</h3>
      {description && <p className="text-gray-500 font-body text-sm mb-4">{description}</p>}
      {action}
    </div>
  );
}

// ─── STAT CARD ────────────────────────────────────────────────────────────────
interface StatCardProps { label: string; value: string | number; icon?: React.ReactNode; color?: string; trend?: number }
export function StatCard({ label, value, icon, color = 'text-primary-400', trend }: StatCardProps) {
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold text-gray-400 font-body uppercase tracking-wider mb-1">{label}</p>
          <p className={cn('font-display font-bold text-2xl', color)}>{value}</p>
          {trend !== undefined && (
            <p className={cn('text-xs font-body mt-1', trend >= 0 ? 'text-emerald-400' : 'text-red-400')}>
              {trend >= 0 ? '↑' : '↓'} {Math.abs(trend)}% ce mois
            </p>
          )}
        </div>
        {icon && <div className={cn('p-2.5 rounded-xl bg-white/10', color)}>{icon}</div>}
      </div>
    </Card>
  );
}

// ─── PROGRESS BAR ─────────────────────────────────────────────────────────────
interface ProgressBarProps { value: number; max?: number; color?: string; label?: string; showPercent?: boolean }
export function ProgressBar({ value, max = 100, color = 'bg-primary-500', label, showPercent }: ProgressBarProps) {
  const pct = Math.min(100, Math.round((value / max) * 100));
  return (
    <div className="w-full">
      {(label || showPercent) && (
        <div className="flex justify-between mb-1.5">
          {label && <span className="text-xs text-gray-400 font-body">{label}</span>}
          {showPercent && <span className="text-xs text-gray-400 font-body">{pct}%</span>}
        </div>
      )}
      <div className="h-2 bg-white/10 rounded-full overflow-hidden">
        <div className={cn('h-full rounded-full transition-all duration-700', color)} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

// ─── TABS ─────────────────────────────────────────────────────────────────────
interface TabsProps { tabs: { id: string; label: string; icon?: React.ReactNode }[]; active: string; onChange: (id: string) => void }
export function Tabs({ tabs, active, onChange }: TabsProps) {
  return (
    <div className="flex bg-white/5 rounded-xl p-1 gap-1">
      {tabs.map(t => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          className={cn(
            'flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold font-body transition-all duration-200',
            active === t.id ? 'bg-primary-600 text-white shadow-sm' : 'text-gray-400 hover:text-white'
          )}
        >
          {t.icon}{t.label}
        </button>
      ))}
    </div>
  );
}
